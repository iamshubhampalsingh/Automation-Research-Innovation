import os
import unittest
import time
import subprocess

from androidutils.device import Device
from androidutils.error import RunWithManualStepsError

## Logs -start
from androidutils.pylogging import PyLogger
logger = PyLogger.getlogger(__name__)
logc = logger.critical
loge = logger.error
logw = logger.warning
logd = logger.debug
logi = logger.info
## Logs -end


class BugreportLite(unittest.TestCase):
    """
    A class to handle BugreportLite test case
    """

    def __init__(self, *args, **kwargs):
      super(BugreportLite, self).__init__(*args, **kwargs)
      self.classname = self.__class__.__name__

    @classmethod
    def setUpClass(cls):
      logw("setup")
      cls.dev = Device()

    @classmethod
    def tearDownClass(cls):
      logw("teardown")
      cls.dev.adbclient.remote_disconnect()

    def msg(self, tag, msg):
       return ("[{}#{}]: {}".format(self.dev.name, tag, msg))

    def start(self, test_case_name):
      logw(self.msg(test_case_name, '---------------------------------'))
      logw(self.msg(test_case_name, "Start test: " + test_case_name))
      logw(self.msg(test_case_name, '---------------------------------'))

    def open_development_apk(self):
      tag = self.classname + ".open_development_apk"
      d = self.dev.uidevice
      if(self.dev.is_screen_locked()):
          self.dev.unlock_lockscreen()
      d.app_start("com.android.development", ".Development")
      d.app_wait("com.android.development", timeout=20.0)
      time.sleep(1)
      if d(text = "Bad Behavior").exists(timeout=5.0):
          d(text='Bad Behavior').click()
      else:
          self.fail("Please install Development APK")

    def test_System_BR_1_BugreportLite(self):
      tag = self.classname + "." + self.test_System_BR_1_BugreportLite.__name__
      self.dev.set_tag(tag)
      self.start(tag)

      # check for process
      output = subprocess.check_output("adb shell ps | grep -i lite", shell=True).decode('ascii').strip()
      if output.find("com.oneplus.opbugreportlite") != -1:
          logd(self.msg(tag, 'opbugreportlite running'))
          ssts_root_path = os.getenv("SSTS_ROOT_PATH")
          ssts_testcases_path = ssts_root_path + "/testcases"
          file = ssts_testcases_path + "/apk/Development_sign.apk"

          if(os.path.exists(file) == False):
            self.fail("APK not present")

          # Install a apk
          subprocess.check_output("adb install %s" % (file), shell=True)
          outputinstall = subprocess.check_output("adb shell pm list packages com.android.development", shell=True).decode('ascii').strip()

          # check if apk install is success
          if(outputinstall != "package:com.android.development"):
              loge(self.msg(tag, 'Development apk install fail'))
          else:
              logd(self.msg(tag, 'Development apk install success'))
              # clear all bugreportlite logs
              subprocess.check_output("adb root && adb remount", shell=True)
              subprocess.check_output("adb shell rm -rf /data/data/com.oneplus.opbugreportlite/files/LiteLog", shell=True)
      else:
          self.fail("opbugreportlite doesnot exist")

    def test_System_BR_2_SystemServerCrash(self):
      tag = self.classname + "." + self.test_System_BR_2_SystemServerCrash.__name__
      self.dev.set_tag(tag)
      self.start(tag)
      d = self.dev.uidevice

      # Open development apk and select bad behaviour
      self.open_development_apk()

      # select CRASH THE SYSTEM SERVER option
      logd(self.msg(tag, 'Triggered system server crash'))
      d(text="CRASH THE SYSTEM SERVER").click()
      time.sleep(60)

      if(self.dev.is_screen_locked()):
          self.dev.unlock_lockscreen()
      time.sleep(10)
      subprocess.check_output("adb root && adb remount", shell=True)
      outputfiles = subprocess.check_output("adb shell ls /data/data/com.oneplus.opbugreportlite/files/LiteLog", shell=True).decode('ascii').strip()
      logd(self.msg(tag, 'BugreportLite files %s' %outputfiles))
      count = 0
      for line in outputfiles.splitlines():
         if line.find("system") != -1:
           count += 1
           logd(self.msg(tag, 'line %s' %line))

      logd(self.msg(tag, 'Count is %d' %count))
      if count < 1 :
         self.fail("System server crash not generated. Check if you have enabled experience stability program")

    def test_System_BR_3_SystemServerWatchdog(self):
      tag = self.classname + "." + self.test_System_BR_3_SystemServerWatchdog.__name__
      self.dev.set_tag(tag)
      self.start(tag)
      d = self.dev.uidevice

      # Open development apk and select bad behaviour
      self.open_development_apk()

      # select WEDGE SYSTEM (5 MINUTE SYSTEM ANR) option
      d(text="WEDGE SYSTEM (5 MINUTE SYSTEM ANR)").click()
      logd(self.msg(tag, 'Triggered system server watchdog'))
      time.sleep(150)

      if(self.dev.is_screen_locked()):
          self.dev.unlock_lockscreen()
      time.sleep(10)
      subprocess.check_output("adb root && adb remount", shell=True)
      outputfiles = subprocess.check_output("adb shell ls /data/data/com.oneplus.opbugreportlite/files/LiteLog", shell=True).decode('ascii').strip()
      logd(self.msg(tag, 'BugreportLite files %s' %outputfiles))
      count = 0
      for line in outputfiles.splitlines():
         if line.find("system") != -1:
           count += 1
           logd(self.msg(tag, 'line %s' %line))

      logd(self.msg(tag, 'Count is %d' %count))
      if count < 2 :
         self.fail("System server watchdog not generated. Check if you have enabled experience stability program")

    def test_System_BR_4_SystemKernelPanic(self):
      tag = self.classname + "." + self.test_System_BR_4_SystemKernelPanic.__name__
      self.dev.set_tag(tag)
      self.start(tag)

      # Execute adb shell command to trigger kernel panic
      logd(self.msg(tag, 'Triggered kernel panic'))
      subprocess.check_output("adb root && adb remount", shell=True)
      self.dev.adbdevice.shell("echo c > /proc/sysrq-trigger")
      time.sleep(150)

      if(self.dev.is_screen_locked()):
          self.dev.unlock_lockscreen()
      time.sleep(10)

      subprocess.check_output("adb root && adb remount", shell=True)
      outputfiles = subprocess.check_output("adb shell ls /data/data/com.oneplus.opbugreportlite/files/LiteLog", shell=True).decode('ascii').strip()
      logd(self.msg(tag, 'BugreportLite files %s' %outputfiles))
      count = 0
      for line in outputfiles.splitlines():
         if line.find("system") != -1:
           count += 1
           logd(self.msg(tag, 'line %s' %line))

      logd(self.msg(tag, 'Count is %d' %count))
      if count < 3 :
         self.fail("System server kernel panic not generated. Check if you have enabled experience stability program")

