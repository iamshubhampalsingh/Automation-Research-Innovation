#!/usr/bin/env python
# -*- coding: utf-8 -*-
# coding=utf-8

# ------------------------------------------------------------
# Copyright (C), 2008-2018, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2018-2019, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2019-2020, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2020-2021, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2021-2022, OPPO Mobile Comm Corp., Ltd.
# ------------------------------------------------------------
# Author: Shubham Pal Singh(shubham.singh@oppo.com)
# ------------------------------------------------------------

import time
from olib_aw.base import TcBase
from olib_aw.base import sim, settings
from olib_aw.base import call, common, asserttip
from olib_aw.teams.test_ui import ui_commont_ as ui2
from olib_aw.base import PreconditionsException, ScriptFail
from olib_scripts.libs.oplus_india import Library_network as lib # pylint:disable=import-error
from olib_aw.utils import set_as_tc


@set_as_tc(
    project_name='India_Network_test',
    script_desc="""
    Make call, receive call; check volte, vowifi state.
    """,
    author='Shubham Pal Singh (IN009359)',
    created_time='2022/02/25',
    modified_time='2022/06/01',
    modified_desc=""" """,
    pre_condition="""
    * initialize_testcase:
    * initialize_iteration
    """,
    test_steps="""
    *  Power up the DUT and wait for network camping on network.
    *  Now initiate Vilte Call to off-net number.
    *  DUT fails to initiate call to off-net number when we try to initiate VT Call to off-net number for Volte operator.
    """,
    post_condition="""
    * cleanup_iteration
    * cleanup_testcase    
    """,
    expection_result="""
    *  DUT should successfully initiate call to off-net number when we try to initiate VT Call to off-net number and switch to audio call
    """,
    topology_dependencies=37,
    devices_tags=[["phoneDUT"], ["phoneSUT1"]]
)
class Network_008(TcBase):
    """ This is the TC template class

    """

    def initialize_testcase(self):
        """ Initialize before every testcase executes

        :return:
        """
        global dut
        dut = self.topology.get_phone(label="phoneDUT")
        self.exception_all = []

        global aux2
        aux2 = self.topology.get_phone(label="phoneSUT1")
        self.exception_all = []

    # def initialize_iteration(self):
    #     """ Initialize before every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def main(self):
        settings.set_system_language(dut, "en", "IN")

        # check network registered
        if sim.is_registered(dut, simid=0) is not True:
            raise PreconditionsException("SIM is not registered")
        self.logger.info("SIM is registered")
        time.sleep(2)

        # make offnet VT call
        if lib.check_operator_name_slot_1(dut) != lib.check_operator_name_slot_1(aux2):
            phnNum = sim.get_phone_number(aux2, simid=0)
            res = call.start_video_call(dut, phnNum, simid=0)
            self.logger.info("VT call initiated:" + str(res))
            time.sleep(5)

        elif sim.is_existed(aux2, simid=1) and lib.check_operator_name_slot_1(dut) != lib.check_operator_name_slot_2(aux2):
            phnNum = sim.get_phone_number(aux2, simid=1)
            res = call.start_video_call(dut, phnNum, simid=0)
            self.logger.info("VT call initiated:" + str(res))
            time.sleep(5)

        else:
            raise PreconditionsException("sim operators are same : can't initiate offnet VT call")

        # accept call in AUX
        res = call.answer_call(aux2)
        self.logger.info("Call received on AUX2 : " + str(res))
        time.sleep(10)

        ui2.open_notification(dut)
        time.sleep(5)
        if ui2.click_with_text(dut, "Ongoing carrier video call") or ui2.click_with_text(dut, "Ongoing operator video call") is True:
            raise ScriptFail("VT call successful to OFF net number: FAIL")

        self.logger.info("VT call not connected for off net number: PASS")
        time.sleep(2)

        # End call
        res = call.end_call(dut, simid=0)
        res = call.end_call(dut, simid=1)
        self.logger.info("Call end : " + str(res))
        time.sleep(2)

        if asserttip.get_assert_state(dut) is True:
            raise ScriptFail("Red screen assertion found in dut")

    # def cleanup_iteration(self):
    #     """ Cleanup every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def cleanup_testcase(self):
        """ Cleanup every testcase executes

        :return:
        """
        call.end_call(dut, simid=0)
        call.end_call(dut, simid=1)

        # clear red screen
        if asserttip.get_assert_state(dut) is True:
            asserttip.clear_assert_red(dut)

        common.press_home_key(dut)
        time.sleep(2)
        common.clear_background_apps(dut, "all")

        common.press_home_key(aux2)
        time.sleep(2)
        common.clear_background_apps(aux2, "all")


if __name__ == '__main__':
    tc = Network_008()
    tc.execute()
