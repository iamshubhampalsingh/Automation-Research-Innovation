#!/usr/bin/env python
# -*- coding: utf-8 -*-
# coding=utf-8

# ------------------------------------------------------------
# Copyright (C), 2008-2018, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2018-2019, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2019-2020, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2020-2021, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2021-2022, OPPO Mobile Comm Corp., Ltd.
# ------------------------------------------------------------
# Author: Shubham Pal Singh(shubham.singh@oppo.com)
# ------------------------------------------------------------

import time
from olib_aw.base import TcBase
from olib_aw.base import sim, asserttip, modem, settings
from olib_aw.teams.test_ui import ui_commont_ as ui2
from olib_aw.base import PreconditionsException, ScriptFail
from olib_scripts.libs.oplus_india import Library_network as lib # pylint:disable=import-error
from olib_aw.utils import set_as_tc


@set_as_tc(
    project_name='India_Network_test',
    script_desc="""
    Make call, receive call; check volte, vowifi state.
    """,
    author='Shubham Pal Singh (IN009359)',
    created_time='2022/02/25',
    modified_time='2022/06/01',
    modified_desc=""" """,
    pre_condition="""
    * initialize_testcase:
    * initialize_iteration
    """,
    test_steps="""
    *  Insert JIO SIM in SUB 1 .
    *  Reboot the device and wait till Both SIM register to the Network.
    *  Enter Settings.
    *  Click on Sim card and & cellular data.
    *  Select SIM 1.
    *  Observe the Preferred Network option.
    *  5G/4G/3G/2G(Auto) & 4G/3G/2G(Auto)(Default) & 3G/2G(Auto) & 2G"

    """,
    post_condition="""
    * cleanup_iteration
    * cleanup_testcase    
    """,
    expection_result="""
    *  DUT should not show the preferred network option for JIO operator for 4G devices,For 5G devices it show 
    4G/3G/2G(Auto)(Default) & 5G/4G/3G/2G(Auto)
    """,
    topology_dependencies=37,
    devices_tags=[["phoneDUT"]]
)
class IN_LO_23(TcBase):
    """ This is the TC template class

    """
    def initialize_testcase(self):
        """ Initialize before every testcase executes

        :return:
        """
        global dut
        dut = self.topology.get_phone(label="phoneDUT")
        self.exception_all = []

    # def initialize_iteration(self):
    #     """ Initialize before every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def main(self):
        settings.set_system_language(dut, "en", "IN")

        # SIM register state
        if sim.is_registered(dut, simid=0) is False:
            raise ScriptFail("SIM1 not registered successfully")

        self.logger.info("SIM1 registered successfully")
        time.sleep(2)

        # check operator name
        res = lib.check_operator_name_slot_1(dut)
        self.logger.info("Network operator in Slot1 is : " + str(res))

        if modem.is_5g_support(dut):
            if res in ["Jio 4G", "Jio", "airtel", "Vodafone IN"]:
                # open sim settings
                lib.open_sim_settings_slot_1(dut)

                # open preferred network type
                res = ui2.click_with_text(dut, "Preferred network type")
                self.logger.info("Click on Preferred network type : " + str(res))
                time.sleep(2)

                # check network options
                if ui2.check_exists_Text(dut, "5G/4G/3G/2G (Auto)") is False:
                    raise ScriptFail("### 5G/4G/3G/2G (Auto) not observed")

                if ui2.check_exists_Text(dut, "4G/3G/2G (Auto)") is False:
                    raise ScriptFail("### 4G/3G/2G (Auto) not observed")

                self.logger.info("preferred network options are present: PASS")
            else:
                raise PreconditionsException("Jio/airtel/vodafone sim not found in slot 1")
        else:
            # open sim settings
            lib.open_sim_settings_slot_1(dut)

            # for JIO sim in 4G device
            if res in ("Jio 4G", "Jio"):
                if ui2.check_exists_Text(dut, "Preferred network type"):
                    raise ScriptFail("Preferred network type option found for JIO in 4G device")
                else:
                    self.logger.info("NO preferred network option found for JIO operator for 4G devices: PASS")

            elif res in ["airtel", "Vodafone IN"]:
                # open preferred network type
                res = ui2.click_with_text(dut, "Preferred network type")
                self.logger.info("Click on Preferred network type : " + str(res))
                time.sleep(2)

                # check network options
                if ui2.check_exists_Text(dut, "4G/3G/2G (Auto)") is False:
                    raise ScriptFail("### 4G/3G/2G (Auto) not observed")

                self.logger.info("preferred network options are present: PASS")
            else:
                raise PreconditionsException("Jio/airtel/vodafone sim not found in slot 1")

        if asserttip.get_assert_state(dut) is True:
            raise ScriptFail("Red screen assertion found in dut")

    # def cleanup_iteration(self):
    #     """ Cleanup every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def cleanup_testcase(self):
        """ Cleanup every testcase executes

        :return:
        """
        lib.cleanup_network(dut)


if __name__ == '__main__':
    tc = IN_LO_23()
    tc.execute()
