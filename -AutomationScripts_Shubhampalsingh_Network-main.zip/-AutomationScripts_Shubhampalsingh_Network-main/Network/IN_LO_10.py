#!/usr/bin/env python
# -*- coding: utf-8 -*-
# coding=utf-8

# ------------------------------------------------------------
# Copyright (C), 2008-2018, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2018-2019, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2019-2020, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2020-2021, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2021-2022, OPPO Mobile Comm Corp., Ltd.
# ------------------------------------------------------------
# Author: Shubham Pal Singh(shubham.singh@oppo.com)
# ------------------------------------------------------------

import time
from olib_aw.base import TcBase
from olib_aw.base import sim
from olib_aw.base import call, settings
from olib_aw.base import network, common, asserttip
from olib_aw.teams.test_ui import ui_commont_ as ui2
from olib_aw.base import PreconditionsException, ScriptFail
from olib_scripts.libs.oplus_india import Library_network as lib # pylint:disable=import-error
from olib_aw.utils import set_as_tc


@set_as_tc(
    project_name='India_Network_test',
    script_desc="""
    Make call, receive call; check volte, vowifi state.
    """,
    author='Shubham Pal Singh (IN009359)',
    created_time='2022/02/25',
    modified_time='2022/06/01',
    modified_desc=""" """,
    pre_condition="""
    * initialize_testcase:
    * initialize_iteration
    """,
    test_steps="""
    *  Power up the device and wait till DUT get registers on available network.
    *  Initiate MO ViLTE call and accept at MT end.
    *  Now try to switch the camera front and back and observe.
    *  observe that DUT fails to switch the camera during ViLTE call

    """,
    post_condition="""
    * cleanup_iteration
    * cleanup_testcase    
    """,
    expection_result="""
    *  DUT should switch the camera during ViLTE call 
    """,
    topology_dependencies=37,
    devices_tags=[["phoneDUT"], ["phoneSUT"]]
)
class Network_010(TcBase):
    """ This is the TC template class

    """

    def initialize_testcase(self):
        """ Initialize before every testcase executes

        :return:
        """
        global dut
        dut = self.topology.get_phone(label="phoneDUT")
        self.exception_all = []

        global aux
        aux = self.topology.get_phone(label="phoneSUT")
        self.exception_all = []

    # def initialize_iteration(self):
    #     """ Initialize before every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def main(self):
        settings.set_system_language(dut, "en", "IN")

        # check network registered
        if sim.is_registered(dut, simid=0) is not True:
            raise ScriptFail("SIM is not registered")
        self.logger.info("SIM is registered")
        time.sleep(2)

        # make VT call
        if lib.check_operator_name_slot_1(dut) == lib.check_operator_name_slot_1(aux):
            phnNum = sim.get_phone_number(aux, simid=0)
            res = call.start_video_call(dut, phnNum, simid=0)
            self.logger.info("VT call initiated:" + str(res))
            time.sleep(4)

        elif sim.is_existed(dut, simid=1) and sim.is_existed(aux, simid=1) and lib.check_operator_name_slot_2(dut) == lib.check_operator_name_slot_2(aux):
            phnNum = sim.get_phone_number(aux, simid=1)
            res = call.start_video_call(dut, phnNum, simid=1)
            self.logger.info("VT call initiated:" + str(res))
            time.sleep(4)

        else:
            raise PreconditionsException(
                "Can't initiate VT call : sim operators are different. Keep in same number slots 1/2")

        if res is not True:
            raise ScriptFail("VT call failed")
        time.sleep(4)

        # accept call in AUX
        res = call.answer_call(aux)
        self.logger.info("Call received on AUX : " + str(res))
        time.sleep(5)

        ui2.open_notification(aux)
        time.sleep(2)
        ui2.click_with_text_exists(aux, "Ongoing carrier video call")
        time.sleep(5)
        ui2.click_with_text_exists(aux, "Ongoing operator video call")
        time.sleep(5)

        # switch camera front/back
        if ui2.click_with_text(dut, "Flip camera") is not True:
            raise ScriptFail("Camera failed to flip")

        self.logger.info("camera flipped")
        time.sleep(10)

        # End call
        res = call.end_call(dut, simid=0)
        self.logger.info("Call end : " + str(res))
        time.sleep(2)

        if asserttip.get_assert_state(dut) is True:
            raise ScriptFail("Red screen assertion found in dut")

    # def cleanup_iteration(self):
    #     """ Cleanup every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def cleanup_testcase(self):
        """ Cleanup every testcase executes

        :return:
        """
        if network.get_data_network_state(dut) is False:
            network.open_data_network(dut)

        # clear red screen
        if asserttip.get_assert_state(dut) is True:
            asserttip.clear_assert_red(dut)

        common.press_home_key(dut)
        time.sleep(2)
        common.clear_background_apps(dut, "all")

        common.press_home_key(aux)
        time.sleep(2)
        common.clear_background_apps(aux, "all")


if __name__ == '__main__':
    tc = Network_010()
    tc.execute()
