#!/usr/bin/env python
# -*- coding: utf-8 -*-
# coding=utf-8

# ------------------------------------------------------------
# Copyright (C), 2008-2018, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2018-2019, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2019-2020, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2020-2021, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2021-2022, OPPO Mobile Comm Corp., Ltd.
# ------------------------------------------------------------
# Author: Shubham Pal Singh(shubham.singh@oppo.com)
# ------------------------------------------------------------

import time
from olib_aw.base import TcBase
from olib_aw.base import common
from olib_aw.base import settings, asserttip
from olib_aw.teams.test_ui import ui_commont_ as ui2
from olib_aw.base import ScriptFail
from olib_scripts.libs.oplus_india import Library_network as lib # pylint:disable=import-error
from olib_aw.utils import set_as_tc


@set_as_tc(
    project_name='India_Network_test',
    script_desc="""
    Make call, receive call; check volte, vowifi state.
    """,
    author='Shubham Pal Singh (IN009359)',
    created_time='2022/02/25',
    modified_time='2022/06/01',
    modified_desc=""" """,
    pre_condition="""
    * initialize_testcase:
    * initialize_iteration
    """,
    test_steps="""
    *  Start the DUT and go to calling application click on 3 Dots>>settings>>calling accounts>>carrier call settings>>call forwarding.
    *  Drag down notification bar and enable DARK mode while reading call forwarding settings and observe DUT."

    """,
    post_condition="""
    * cleanup_iteration
    * cleanup_testcase    
    """,
    expection_result="""
    *  DUT should read call forwarding settings after enabling dark mode
    """,
    topology_dependencies=37,
    devices_tags=[["phoneDUT"]]
)
class IN_LO_57(TcBase):
    """ This is the TC template class

    """

    def initialize_testcase(self):
        """ Initialize before every testcase executes

        :return:
        """
        global dut
        dut = self.topology.get_phone(label="phoneDUT")
        self.exception_all = []

    # def initialize_iteration(self):
    #     """ Initialize before every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def main(self):
        settings.set_system_language(dut, "en", "IN")

        osversion = common.exec_shell_command(dut, "getprop ro.build.version.release")
        self.logger.info("OS version is: {}".format(osversion))
        time.sleep(2)
        osversion1 = osversion.strip()

        if osversion1 == "13":
            res = common.start_app_activity(dut, "com.android.phone", "com.android.phone.OplusCallCarrierSetting")
            self.logger.info("Call Advanced settings open: " + str(res))
            time.sleep(2)

        else:
            res = common.start_app_activity(dut, "com.android.phone", "com.android.phone.OplusCallAdvancedSetting")
            self.logger.info("Call Advanced settings open: " + str(res))
            time.sleep(2)

        ui2.click_with_text(dut, "Call forwarding")
        time.sleep(2)
        ui2.click_with_text_exists(dut, "SIM1")
        time.sleep(2)

        if lib.check_operator_name_slot_1(dut) in ("Jio 4G", "Jio"):
            ui2.click_with_text_exists(dut, "Voice Call")
            time.sleep(2)

        settings.open_dark_mode(dut)
        self.logger.info("Dark mode is ON")
        time.sleep(30)

        if common.is_activity_exist(dut, "com.android.phone", "com.android.phone.GsmUmtsCallForwardOptions") is True:
            self.logger.info("DUT read call forwarding in dark mode")
        else:
            raise ScriptFail("DUT unable to read call forwarding in dark mode")

        if lib.check_operator_name_slot_1(dut) in ("Jio 4G", "Jio"):
            common.press_back_key(dut)
            time.sleep(2)

            ui2.click_with_text_exists(dut, "Video Call")
            time.sleep(2)

            settings.open_dark_mode(dut)
            self.logger.info("Dark mode is ON")
            time.sleep(30)

            if common.is_activity_exist(dut, "com.android.phone", "com.android.phone.GsmUmtsCallForwardOptions") is True:
                self.logger.info("DUT read call forwarding in dark mode")
            else:
                raise ScriptFail("DUT unable to read call forwarding in dark mode")

        if asserttip.get_assert_state(dut) is True:
            raise ScriptFail("Red screen assertion found in dut")

    # def cleanup_iteration(self):
    #     """ Cleanup every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def cleanup_testcase(self):
        """ Cleanup every testcase executes

        :return:
        """
        lib.cleanup_network(dut)


if __name__ == '__main__':
    tc = IN_LO_57()
    tc.execute()
