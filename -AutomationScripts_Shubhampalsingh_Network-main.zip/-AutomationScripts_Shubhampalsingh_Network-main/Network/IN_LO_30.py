#!/usr/bin/env python
# -*- coding: utf-8 -*-
# coding=utf-8

# ------------------------------------------------------------
# Copyright (C), 2008-2018, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2018-2019, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2019-2020, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2020-2021, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2021-2022, OPPO Mobile Comm Corp., Ltd.
# ------------------------------------------------------------
# Author: Shubham Pal Singh(shubham.singh@oppo.com)
# ------------------------------------------------------------

import time
from olib_aw.base import TcBase
from olib_aw.base import modem, ScriptFail, settings
from olib_aw.base import wifi, sim, common, asserttip
from olib_scripts.libs.oplus_india import Library_network as lib # pylint:disable=import-error
from olib_aw.utils import set_as_tc


@set_as_tc(
    project_name='India_Network_test',
    script_desc="""
    Make call, receive call; check volte, vowifi state.
    """,
    author='Shubham Pal Singh (IN009359)',
    created_time='2022/02/25',
    modified_time='2022/06/01',
    modified_desc=""" """,
    pre_condition="""
    * initialize_testcase:
    * initialize_iteration
    """,
    test_steps="""
    *   1.Connect with WIFI hotspot,Wait DUT to register on VOWIFI with both SUB.
    *   2.Keep DUT under observation overnight.

    """,
    post_condition="""
    * cleanup_iteration
    * cleanup_testcase    
    """,
    expection_result="""
    *   1.DUT should be able to register on VOWIFI with both SUB successfully.
    *   2.After DUT keep under observation overnight,DUT should keep registered with VOWIFI and there's no any dump and red screen issue.
    """,
    topology_dependencies=37,
    set_case_max_timeout=7*60*60,
    devices_tags=[["phoneDUT"], ["phoneSUT1"]]
)
class Network_030(TcBase):
    """ This is the TC template class

    """
    def initialize_testcase(self):
        """ Initialize before every testcase executes

        :return:
        """
        global dut
        dut = self.topology.get_phone(label="phoneDUT")
        self.exception_all = []

        global aux2
        aux2 = self.topology.get_phone(label="phoneSUT1")
        self.exception_all = []

    # def initialize_iteration(self):
    #     """ Initialize before every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def main(self):
        settings.set_system_language(dut, "en", "IN")
        time.sleep(1)
        res = modem.get_vowifi_mode(dut, simid=0)
        if res == 2:
            self.logger.info("WiFi prefer is set in sim1")
        # set wifi calling prefer for airtel
        if lib.check_operator_name_slot_1(dut) == "airtel":
            lib.set_wifi_calling_prefer(dut, simid=0)

        if sim.is_existed(dut, simid=1):
            res = modem.get_vowifi_mode(dut, simid=1)
            if res == 2:
                self.logger.info("WiFi prefer is set in sim2")
                time.sleep(1)

            if lib.check_operator_name_slot_2(dut) == "airtel":
                lib.set_wifi_calling_prefer(dut, simid=1)

        # connect DUT to hotspot
        lib.create_hotspot(aux2)
        time.sleep(2)

        lib.connect_to_wifi_hotspot(dut)

        # check VoWIFI in dut
        lib.check_vowifi_state(dut)

        # check VoWIFI state overnight 6hrs
        for i in range(360):
            self.logger.info("Started Iteration number : " + str(i+1))

            # check VoWIFI in sim1
            lib.check_vowifi_state(dut)

            if asserttip.get_assert_state(dut) is True:
                raise ScriptFail("Red screen assertion found in dut")
            time.sleep(60)

    # def cleanup_iteration(self):
    #     """ Cleanup every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def cleanup_testcase(self):
        """ Cleanup every testcase executes

        :return:
        """
        lib.forget_all_saved_wifi(dut)

        lib.close_hotspot(aux2)

        if wifi.is_wifi_opened(dut) is True:
            wifi.close_wifi(dut)

        # clear red screen
        if asserttip.get_assert_state(dut) is True:
            asserttip.clear_assert_red(dut)

        common.press_home_key(dut)
        time.sleep(2)
        common.clear_background_apps(dut, "all")

        common.press_home_key(aux2)
        time.sleep(2)
        common.clear_background_apps(aux2, "all")


if __name__ == '__main__':
    tc = Network_030()
    tc.execute()
