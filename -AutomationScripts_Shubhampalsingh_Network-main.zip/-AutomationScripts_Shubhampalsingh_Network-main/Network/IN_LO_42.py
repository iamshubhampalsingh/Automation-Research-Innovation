#!/usr/bin/env python
# -*- coding: utf-8 -*-
# coding=utf-8

# ------------------------------------------------------------
# Copyright (C), 2008-2018, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2018-2019, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2019-2020, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2020-2021, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2021-2022, OPPO Mobile Comm Corp., Ltd.
# ------------------------------------------------------------
# Author: Shubham Pal Singh(shubham.singh@oppo.com)
# ------------------------------------------------------------

import time
from olib_aw.base import TcBase
from olib_aw.base import common, settings, sim, asserttip
from olib_aw.teams.test_ui import ui_commont_ as ui2
from olib_aw.base import ScriptFail, PreconditionsException
from olib_scripts.libs.oplus_india import Library_network as lib # pylint:disable=import-error
from olib_aw.utils import set_as_tc


@set_as_tc(
    project_name='India_Network_test',
    script_desc="""
    Make call, receive call; check volte, vowifi state.
    """,
    author='Shubham Pal Singh (IN009359)',
    created_time='2022/02/25',
    modified_time='2022/06/01',
    modified_desc=""" """,
    pre_condition="""
    * initialize_testcase:
    * initialize_iteration
    """,
    test_steps="""
    *  When device support 5 network mode in primary sub or in both sub, select 5/4/3/2G option
    *  Go to smart 5G option in this path
        settings-->SIM card & Mobile data-->advanced settings-->Smart 5G, Check smart 5G option if it is enabled
    *  Select other network mode as 4/3/2G, 3/2G,2G, Check smart 5G option if it is grey out

    """,
    post_condition="""
    * cleanup_iteration
    * cleanup_testcase    
    """,
    expection_result="""
    *  Smart 5G option should be enabled when select 5/4/3/2G option
    *  Smart 5G option should be grey out when select other network mode

    """,
    topology_dependencies=37,
    devices_tags=[["phoneDUT"]]
)
class Network_042(TcBase):
    """ This is the TC template class

    """

    def initialize_testcase(self):
        """ Initialize before every testcase executes

        :return:
        """
        global dut
        dut = self.topology.get_phone(label="phoneDUT")
        self.exception_all = []

    # def initialize_iteration(self):
    #     """ Initialize before every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def main(self):
        settings.set_system_language(dut, "en", "IN")

        # check for sim 1
        lib.open_sim_settings_slot_1(dut)
        ui2.click_with_text(dut, "Preferred network type")
        time.sleep(2)

        ui2.click_with_text(dut, "Preferred network type")
        time.sleep(2)

        res = ui2.click_with_text(dut, "5G/4G/3G/2G (Auto)")
        self.logger.info("5G/4G/3G/2G selected: " + str(res))
        time.sleep(2)
        if res is False:
            raise PreconditionsException("5G not supported in primary sub")

        common.press_back_key(dut)
        time.sleep(2)

        osversion = common.exec_shell_command(dut, "getprop ro.build.version.release")
        self.logger.info("OS version is: {}".format(osversion))
        time.sleep(2)
        osversion1 = osversion.strip()

        if osversion1 == "13":
            ui2.click_with_text(dut, "More settings")
            time.sleep(2)
        else:
            ui2.click_with_text(dut, "Advanced settings")
            time.sleep(2)

        if ui2.is_enabled_true_by_text(dut, "Smart 5G") is True:
            self.logger.info("Smart 5G switch is enabled in 5G/4G/3G/2G mode")
            time.sleep(2)
        else:
            raise ScriptFail("Smart 5G switch is NOT enabled/available in 5G/4G/3G/2G mode in SIM 1")

        common.press_back_key(dut)
        time.sleep(2)

        lib.open_sim_settings_slot_1(dut)

        ui2.click_with_text(dut, "Preferred network type")
        time.sleep(2)

        res = ui2.click_with_text(dut, "4G/3G/2G (Auto)")
        self.logger.info("4G/3G/2G selected: " + str(res))
        time.sleep(3)

        common.press_back_key(dut)
        time.sleep(2)

        if osversion1 == "13":
            ui2.click_with_text(dut, "More settings")
            time.sleep(1)
        else:
            ui2.click_with_text(dut, "Advanced settings")
            time.sleep(2)

        if ui2.is_enabled_true_by_text(dut, "Smart 5G") is False:
            self.logger.info("Smart 5G switch is not enabled/available in 4G/3G/2G mode in SIM 1")
        else:
            raise ScriptFail("Smart 5G switch is enabled in 4G/3G/2G mode")
        time.sleep(2)

        common.press_back_key(dut)
        time.sleep(2)

        # check for sim 2
        if sim.is_existed(dut, simid=1):
            lib.open_sim_settings_slot_2(dut)
            ui2.click_with_text(dut, "Preferred network type")
            time.sleep(2)

            ui2.click_with_text(dut, "Preferred network type")
            time.sleep(2)

            res = ui2.click_with_text(dut, "5G/4G/3G/2G (Auto)")
            self.logger.info("5G/4G/3G/2G selected: " + str(res))
            time.sleep(2)
            if res is True:
                common.press_back_key(dut)
                time.sleep(2)

                if osversion1 == "13":
                    ui2.click_with_text(dut, "More settings")
                    time.sleep(2)
                else:
                    ui2.click_with_text(dut, "Advanced settings")
                    time.sleep(2)

                if ui2.is_enabled_true_by_text(dut, "Smart 5G") is True:
                    self.logger.info("Smart 5G switch is enabled in 5G/4G/3G/2G mode")
                    time.sleep(2)
                else:
                    raise ScriptFail("Smart 5G switch is NOT enabled/available in 5G/4G/3G/2G mode in SIM 2")

                common.press_back_key(dut)
                time.sleep(2)

                lib.open_sim_settings_slot_2(dut)

                ui2.click_with_text(dut, "Preferred network type")
                time.sleep(2)

                res = ui2.click_with_text(dut, "4G/3G/2G (Auto)")
                self.logger.info("4G/3G/2G selected: " + str(res))
                time.sleep(2)

                common.press_back_key(dut)
                time.sleep(2)

                if osversion1 == "13":
                    ui2.click_with_text(dut, "More settings")
                    time.sleep(2)
                else:
                    ui2.click_with_text(dut, "Advanced settings")
                    time.sleep(2)

                if ui2.is_enabled_true_by_text(dut, "Smart 5G") is False:
                    self.logger.info("Smart 5G switch is not enabled/available in 4G/3G/2G mode in SIM 2")
                    time.sleep(2)
                else:
                    raise ScriptFail("Smart 5G switch is enabled in 4G/3G/2G mode")

            else:
                self.logger.info("5G not supported in secondary slot")
                common.press_back_key(dut)
                time.sleep(2)

        if asserttip.get_assert_state(dut) is True:
            raise ScriptFail("Red screen assertion found in dut")

    # def cleanup_iteration(self):
    #     """ Cleanup every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def cleanup_testcase(self):
        """ Cleanup every testcase executes

        :return:
        """
        common.press_back_key(dut)
        time.sleep(2)

        lib.open_sim_settings_slot_1(dut)

        ui2.click_with_text(dut, "Preferred network type")
        time.sleep(2)

        res = ui2.click_with_text(dut, "4G/3G/2G (Auto)")
        self.logger.info("4G/3G/2G selected: " + str(res))
        time.sleep(2)

        # clear red screen
        if asserttip.get_assert_state(dut) is True:
            asserttip.clear_assert_red(dut)

        common.press_home_key(dut)
        time.sleep(2)
        common.clear_background_apps(dut, "all")


if __name__ == '__main__':
    tc = Network_042()
    tc.execute()
