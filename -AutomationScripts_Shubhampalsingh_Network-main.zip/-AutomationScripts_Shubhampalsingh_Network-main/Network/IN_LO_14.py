#!/usr/bin/env python
# -*- coding: utf-8 -*-
# coding=utf-8

# ------------------------------------------------------------
# Copyright (C), 2008-2018, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2018-2019, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2019-2020, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2020-2021, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2021-2022, OPPO Mobile Comm Corp., Ltd.
# ------------------------------------------------------------
# Author: Shubham Pal Singh(shubham.singh@oppo.com)
# ------------------------------------------------------------

import time
from olib_aw.base import TcBase
from olib_aw.base import sim, settings
from olib_aw.base import call, common, asserttip
from olib_aw.teams.test_ui import ui_commont_ as ui2
from olib_aw.base import ScriptFail
from olib_aw.utils import set_as_tc


@set_as_tc(
    project_name='India_Network_test',
    script_desc="""
    Make call, receive call; check volte, vowifi state.
    """,
    author='Shubham Pal Singh (IN009359)',
    created_time='2022/02/25',
    modified_time='2022/06/01',
    modified_desc=""" """,
    pre_condition="""
    * initialize_testcase:
    * initialize_iteration
    """,
    test_steps="""
    *  Power up the device and wait till it latches on the network.
    *  Wait for both Subs to register over IMS.
    *  Now Open Dial Pad and Dial #43# and *43# to Disable and Enable Call waiting Settings.
    *  Now make MO VoLTE Call after Accepting Call the Accept MT Call on DUT.
    *  Now try to swap the Calls
    *  Observed DUT Fails to Swap the calls and All Calls Disconnected Automatically.
    *  Now Again make MT Call to DUT and Observed the behavior.
    *  Observed DUT Fails to Receive MT call i.e. Soon after Accepting the Call, Call is Disconnected Automatically.
    """,
    post_condition="""
    * cleanup_iteration
    * cleanup_testcase    
    """,
    expection_result="""
    *  DUT should not Fails to Receive VoLTE/ViLTE Call after Running Supplementary Services for Operator.
    """,
    topology_dependencies=37,
    devices_tags=[["phoneDUT"], ["phoneSUT"], ["phoneSUT1"]]
)
class Network_014(TcBase):
    """ This is the TC template class

    """

    def initialize_testcase(self):
        """ Initialize before every testcase executes

        :return:
        """
        global dut
        dut = self.topology.get_phone(label="phoneDUT")
        self.exception_all = []

        global aux
        aux = self.topology.get_phone(label="phoneSUT")
        self.exception_all = []

        global aux2
        aux2 = self.topology.get_phone(label="phoneSUT1")
        self.exception_all = []

    # def initialize_iteration(self):
    #     """ Initialize before every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def main(self):
        settings.set_system_language(dut, "en", "IN")

        # check ims
        if sim.is_ims_registered(dut, simid=0) is not True:
            raise ScriptFail("IMS is not registered on SIM1")
        self.logger.info("IMS is registered on SIM1")
        time.sleep(2)

        # check ims in sim 2
        if sim.is_existed(dut, simid=1):
            if sim.is_ims_registered(dut, simid=1) is not True:
                raise ScriptFail("IMS is not registered on SIM2")
            self.logger.info("IMS is registered on SIM2")
            time.sleep(2)

        # disable/enable call waiting services
        # dial USSD #43# to disable
        res = call.start_voice_call(dut, "#43#", simid=0)
        self.logger.info("USSD dial process started : " + str(res))
        time.sleep(5)

        ui2.click_with_resource_id_exists(dut, "com.android.phone:id/buttonPanel")
        time.sleep(2)

        # dial *43# to enable
        res = call.start_voice_call(dut, "*43#", simid=0)
        self.logger.info("USSD dial process started : " + str(res))
        time.sleep(5)

        ui2.click_with_resource_id_exists(dut, "com.android.phone:id/buttonPanel")
        time.sleep(2)

        # dial AUX
        phnNum = sim.get_phone_number(aux, simid=0)
        res = call.start_voice_call(dut, phnNum, simid=0)
        self.logger.info("Dial process started : " + str(res))
        time.sleep(5)

        # AUX receive call
        res = call.answer_call(aux)
        self.logger.info("Call received on AUX : " + str(res))
        time.sleep(5)

        # make MT call to DUT
        phnNum = sim.get_phone_number(dut, simid=0)
        res = call.start_voice_call(aux2, phnNum, simid=0)
        self.logger.info("Dial process started : " + str(res))
        time.sleep(2)

        # receive at DUT
        res = call.answer_call(dut)
        self.logger.info("Call received on DUT : " + str(res))
        time.sleep(5)

        # swap calls
        res = ui2.click_with_text(dut, "Swap")
        self.logger.info("Click on call swap: {}".format(res))
        time.sleep(5)

        # check call status on DUT
        call_status = call.get_call_status(dut, simid=0)
        if call_status == "ACTIVE":
            self.logger.info("Ongoing call status: " + str(call_status))

        else:
            raise ScriptFail("## Ongoing call not active")

        # End call DUT
        res = call.end_call(dut, simid=0)
        self.logger.info("Call end : " + str(res))
        time.sleep(5)

        # end call AUX2
        res = call.end_call(aux2, simid=0)
        self.logger.info("Call end : " + str(res))
        time.sleep(2)

        if asserttip.get_assert_state(dut) is True:
            raise ScriptFail("Red screen assertion found in dut")

    # def cleanup_iteration(self):
    #     """ Cleanup every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def cleanup_testcase(self):
        """ Cleanup every testcase executes

        :return:
        """
        call.end_call(dut, simid=0)
        call.end_call(aux2, simid=0)

        # clear red screen
        if asserttip.get_assert_state(dut) is True:
            asserttip.clear_assert_red(dut)

        common.press_home_key(dut)
        time.sleep(2)
        common.clear_background_apps(dut, "all")

        common.press_home_key(aux)
        time.sleep(2)
        common.clear_background_apps(aux, "all")

        common.press_home_key(aux2)
        time.sleep(2)
        common.clear_background_apps(aux2, "all")


if __name__ == '__main__':
    tc = Network_014()
    tc.execute()
