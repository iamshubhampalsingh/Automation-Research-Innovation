#!/usr/bin/env python
# -*- coding: utf-8 -*-
# coding=utf-8

# ------------------------------------------------------------
# Copyright (C), 2008-2018, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2018-2019, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2019-2020, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2020-2021, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2021-2022, OPPO Mobile Comm Corp., Ltd.
# ------------------------------------------------------------
# Author: Shubham Pal Sigh(shubham.singh@oppo.com)
# ------------------------------------------------------------

import time
from olib_aw.base import TcBase, ScriptFail
from olib_aw.base import common
from olib_aw.base import modem, settings
from olib_aw.base import wifi, sim, asserttip
from olib_aw.teams.test_ui import ui_commont_ as ui2
from olib_scripts.libs.oplus_india import Library_network as lib # pylint:disable=import-error
from olib_aw.utils import set_as_tc


@set_as_tc(
    project_name='India_Network_test',
    script_desc="""
    Make call, receive call; check volte, vowifi state.
    """,
    author='Shubham Pal Singh (IN009359)',
    created_time='2022/02/25',
    modified_time='2022/06/01',
    modified_desc=""" """,
    pre_condition="""
    * initialize_testcase:
    * initialize_iteration
    """,
    test_steps="""
    *  switch on Phone -> switch on logs->  Goto settings ->
    *  Turn ON APM mode -> now go to settings -> turn on Wifi -> let DUT connect to WIfi
    *  go to dual SIM and Network SIM1/2  ->
    *  turn On Vowifi service -> observe
    """,
    post_condition="""
    * cleanup_iteration
    * cleanup_testcase    
    """,
    expection_result="""
    *  DUT should not register VOWIFI in Airplane mode
    """,
    topology_dependencies=37,
    devices_tags=[["phoneDUT"], ["phoneSUT"]]
)
class Network_015(TcBase):
    """ This is the TC template class

    """

    def initialize_testcase(self):
        """ Initialize before every testcase executes

        :return:
        """
        global dut
        dut = self.topology.get_phone(label="phoneDUT")
        self.exception_all = []

        global aux
        aux = self.topology.get_phone(label="phoneSUT")
        self.exception_all = []

    # def initialize_iteration(self):
    #     """ Initialize before every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def main(self):
        settings.set_system_language(dut, "en", "IN")

        # set wifi calling prefer for airtel
        if lib.check_operator_name_slot_1(dut) is "airtel":
            lib.set_wifi_calling_prefer(dut, simid=0)
        elif sim.is_existed(dut, simid=1) and lib.check_operator_name_slot_2(dut) is "airtel":
            lib.set_wifi_calling_prefer(dut, simid=1)

        # enable airplane mode
        if modem.get_airplane_mode(dut) is False:
            modem.open_airplane_mode(dut)
            time.sleep(2)

        self.logger.info("Airplane mode is ON")

        # turn on hotspot in AUX
        ui2.open_quick_settings(aux)
        lib.create_hotspot(aux)
        time.sleep(2)

        # connect DUT to WiFi
        lib.connect_to_wifi_hotspot(dut)

        # check voWifi state sim 1
        lib.open_sim_settings_slot_1(dut)
        ui2.click_with_text(dut, "Wi-Fi Calling")
        time.sleep(2)
        if dut.phoneui2(className="android.widget.Switch")[0].info.get("checked") is True:
            self.logger.info("VoWIFI service is ON")
            time.sleep(2)
        else:
            dut.phoneui2(className="android.widget.Switch")[0].click()
            self.logger.info("VoWIFI service is turned ON")

        if sim.get_vowifi_register_state(dut, simid=0) is True:
            raise ScriptFail("Sim 1 vowifi registered in APM mode: FAIL")

        self.logger.info("sim 1 vowifi not registered in APM : PASS")

        common.press_home_key(dut)
        time.sleep(2)
        common.clear_background_apps(dut, "all")

        # check voWifi state sim 2
        if sim.is_existed(dut, simid=1):
            lib.open_sim_settings_slot_2(dut)
            ui2.click_with_text(dut, "Wi-Fi Calling")
            time.sleep(2)
            if dut.phoneui2(className="android.widget.Switch")[0].info.get("checked") is True:
                self.logger.info("VoWIFI service is ON")
                time.sleep(2)
            else:
                dut.phoneui2(className="android.widget.Switch")[0].click()
                self.logger.info("VoWIFI service is turned ON")

            if sim.get_vowifi_register_state(dut, simid=1) is True:
                raise ScriptFail("Sim 2 vowifi registered in APM mode: FAIL")

            self.logger.info("sim 2 vowifi not registered in APM : PASS")

        if asserttip.get_assert_state(dut) is True:
            raise ScriptFail("Red screen assertion found in dut")

    # def cleanup_iteration(self):
    #     """ Cleanup every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def cleanup_testcase(self):
        """ Cleanup every testcase executes

        :return:
        """
        wifi.remove_all_wifi(dut)
        time.sleep(2)

        if wifi.get_personal_hotspot_status(aux) is True:
            wifi.close_personal_hotspot(aux)

        time.sleep(2)

        if wifi.is_wifi_opened(dut) is True:
            wifi.close_wifi(dut)

        if modem.get_airplane_mode(dut) is True:
            modem.close_airplane_mode(dut)

        time.sleep(2)
        # clear red screen
        if asserttip.get_assert_state(dut) is True:
            asserttip.clear_assert_red(dut)

        common.press_home_key(dut)
        time.sleep(2)
        common.clear_background_apps(dut, "all")

        common.press_home_key(aux)
        time.sleep(2)
        common.clear_background_apps(aux, "all")


if __name__ == '__main__':
    tc = Network_015()
    tc.execute()
