#!/usr/bin/env python
# -*- coding: utf-8 -*-
# coding=utf-8

# ------------------------------------------------------------
# Copyright (C), 2008-2018, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2018-2019, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2019-2020, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2020-2021, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2021-2022, OPPO Mobile Comm Corp., Ltd.
# ------------------------------------------------------------
# Author: Shubham Pal Singh(shubham.singh@oppo.com)
# ------------------------------------------------------------

import time
from olib_aw.base import TcBase
from olib_aw.base import common
from olib_aw.base import ui
from olib_aw.base import sim, settings
from olib_aw.base import call, asserttip
from olib_aw.teams.test_ui import ui_commont_ as ui2
from olib_aw.base import ScriptFail
from olib_aw.utils import set_as_tc


@set_as_tc(
    project_name='India_Network_test',
    script_desc="""
    Make call, receive call; check volte, vowifi state.
    """,
    author='Shubham Pal Singh(IN009359)',
    created_time='2022/02/25',
    modified_time='2022/06/01',
    modified_desc=""" """,
    pre_condition="""
    * initialize_testcase:
    * initialize_iteration
    """,
    test_steps="""
    *  Insert Sim in SUB1 and SUB2
    *  Make MO call and receive at MT side
    *  Check for call recording
    *  Reboot the device 
    *  Make MO call and receive at MT side
    *  Check for call recording"
    """,
    post_condition="""
    * cleanup_iteration
    * cleanup_testcase    
    """,
    expection_result="""
    *   1~3. DUT should have call recording option in dialer
    *   4`6. DUT should have call recording option in dialer
    """,
    topology_dependencies=37,
    devices_tags=[["phoneDUT"], ["phoneSUT"]]
)
class Network_049(TcBase):
    """ This is the TC template class

    """

    def initialize_testcase(self):
        """ Initialize before every testcase executes

        :return:
        """
        global dut
        dut = self.topology.get_phone(label="phoneDUT")
        self.exception_all = []

        global aux
        aux = self.topology.get_phone(label="phoneSUT")
        self.exception_all = []

    # def initialize_iteration(self):
    #     """ Initialize before every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def main(self):
        settings.set_system_language(dut, "en", "IN")

        # dial AUX
        phnNum = sim.get_phone_number(aux, simid=0)
        res = call.start_voice_call(dut, phnNum, simid=0)
        self.logger.info("Dial process started : " + str(res))
        time.sleep(5)

        # AUX receive call
        res = call.answer_call(aux)
        self.logger.info("Call received on AUX : " + str(res))
        time.sleep(5)

        # check for call recording option
        if ui2.check_exists_Text(dut, "Record") is True:
            self.logger.info("Call recording option is available")
        else:
            res = ui.screen_simple_swipe(dut, 1000, 1500, 60, 1500, steps=10)
            self.logger.info("swipe left: " + str(res))
            if ui2.check_exists_Text(dut, "Record") is True:
                self.logger.info("Call recording option is available")
                time.sleep(2)
            else:
                raise ScriptFail("Call recording option is not available")

        # End call
        res = call.end_call(dut, simid=0)
        self.logger.info("Call end : " + str(res))
        time.sleep(2)

        '''# restart device
        res = common.reboot(dut)
        self.logger.info("Device restarting: {}".format(res))

        res = common.wait_for_device(dut, timeout=6000)
        self.logger.info("device restarted: {}".format(res))

        dut.phoneui2.screen_on()
        time.sleep(2)
        dut.phoneui2.unlock()
        time.sleep(2)

        screen.set_screen_light(dut)
        time.sleep(2)
        res = screen.unlock_light_screen(dut)
        self.logger.info("Device unlocked after restart: {}".format(res))
        time.sleep(5)

        common.press_home_key(dut)
        time.sleep(2)
        common.clear_background_apps(dut, "all")

        # dial AUX
        phnNum = sim.get_phone_number(aux, simid=0)
        res = call.start_voice_call(dut, phnNum, simid=0)
        self.logger.info("Dial process started after reboot : " + str(res))
        time.sleep(4)

        # AUX receive call
        res = call.answer_call(aux)
        self.logger.info("Call received on AUX after reboot : " + str(res))
        time.sleep(6)

        # check for call recording option
        if ui2.check_exists_Text(dut, "Record") is True:
            self.logger.info("Call recording option is available")
        else:
            res = ui.screen_simple_swipe(dut, 1000, 1500, 60, 1500, steps=10)
            self.logger.info("swipe left: " + str(res))
            if ui2.check_exists_Text(dut, "Record") is True:
                self.logger.info("Call recording option is available")
                time.sleep(2)
            else:
                raise ScriptFail("Call recording option is not available after reboot")

        # End call
        res = call.end_call(dut, simid=0)
        self.logger.info("Call end : " + str(res))
        time.sleep(2)'''

        if asserttip.get_assert_state(dut) is True:
            raise ScriptFail("Red screen assertion found in dut")

    # def cleanup_iteration(self):
    #     """ Cleanup every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def cleanup_testcase(self):
        """ Cleanup every testcase executes

        :return:
        """
        call.end_call(dut, simid=0)
        # clear red screen
        if asserttip.get_assert_state(dut) is True:
            asserttip.clear_assert_red(dut)

        common.press_home_key(dut)
        time.sleep(2)
        common.clear_background_apps(dut, "all")

        common.press_home_key(aux)
        time.sleep(2)
        common.clear_background_apps(aux, "all")


if __name__ == '__main__':
    tc = Network_049()
    tc.execute()
