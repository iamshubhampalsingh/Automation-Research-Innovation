#!/usr/bin/env python
# -*- coding: utf-8 -*-
# coding=utf-8

# ------------------------------------------------------------
# Copyright (C), 2008-2018, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2018-2019, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2019-2020, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2020-2021, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2021-2022, OPPO Mobile Comm Corp., Ltd.
# ------------------------------------------------------------
# Author: Shubham Pal Singh(shubham.singh@oppo.com)
# ------------------------------------------------------------

import time
from olib_aw.base import TcBase
from olib_aw.base import call, sim
from olib_aw.base import wifi, settings, common, asserttip
from olib_aw.teams.test_ui import ui_commont_ as ui2
from olib_aw.base import ScriptFail
from olib_scripts.libs.oplus_india import Library_network as lib # pylint:disable=import-error
from olib_aw.utils import set_as_tc


@set_as_tc(
    project_name='India_Network_test',
    script_desc="""
    Make call, receive call; check volte, vowifi state.
    """,
    author='Shubham Pal Singh (IN009359)',
    created_time='2022/02/25',
    modified_time='2022/06/01',
    modified_desc=""" """,
    pre_condition="""
    * initialize_testcase:
    * initialize_iteration
    """,
    test_steps="""
    *  Connect with WIFI hotspot,Wait DUT to register on VOWIFI.
    *  Make emergency call with number like(911,112,100,101,102,108)"

    """,
    post_condition="""
    * cleanup_iteration
    * cleanup_testcase    
    """,
    expection_result="""
    *  DUT should be able to make emergency call 

    """,
    topology_dependencies=37,
    devices_tags=[["phoneDUT"], ["phoneSUT"], ["phoneSUT1"]]
)
class Network_033(TcBase):
    """ This is the TC template class

    """

    def initialize_testcase(self):
        """ Initialize before every testcase executes

        :return:
        """
        global dut
        dut = self.topology.get_phone(label="phoneDUT")
        self.exception_all = []

        global aux
        aux = self.topology.get_phone(label="phoneSUT")
        self.exception_all = []

        global aux2
        aux2 = self.topology.get_phone(label="phoneSUT1")
        self.exception_all = []

    # def initialize_iteration(self):
    #     """ Initialize before every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def main(self):
        settings.set_system_language(dut, "en", "IN")

        # set wifi calling prefer for airtel
        if lib.check_operator_name_slot_1(dut) == "airtel":
            lib.set_wifi_calling_prefer(dut, simid=0)

        # connect DUT to hotspot
        lib.create_hotspot(aux2)
        time.sleep(2)

        lib.connect_to_wifi_hotspot(dut)

        # check for op1
        lib.check_vowifi_state_sim1(dut)

        # dial emergency number
        phnNum = "112"
        res = call.start_voice_call(dut, phnNum, simid=0)
        self.logger.info("Dial process started : " + str(res))
        time.sleep(5)

        # check ongoing call
        status = ["ACTIVE", "DIALING", "IDLE"]
        call_status = call.get_call_status(dut, simid=0)
        self.logger.info("call status: " + call_status)
        if call_status in status:
            self.logger.info("Ongoing call status: " + str(call_status))

        else:
            raise ScriptFail("## Emergency call not started")

        # End call
        ui2.click_with_resource_id_exists(dut, "com.google.android.dialer:id/incall_end_call")
        self.logger.info("Call end : ")
        time.sleep(5)

        # check for op2
        if sim.is_existed(dut, simid=1):
            # set wifi calling prefer for airtel
            if lib.check_operator_name_slot_2(dut) is "airtel":
                lib.set_wifi_calling_prefer(dut, simid=1)

            lib.check_vowifi_state_sim2(dut)

            # dial emergency number
            phnNum = "112"
            res = call.start_voice_call(dut, phnNum, simid=1)
            self.logger.info("Dial process started : " + str(res))
            time.sleep(5)

            # check ongoing call
            call_status = call.get_call_status(dut, simid=1)
            self.logger.info("call status: " + call_status)
            if call_status in status:
                self.logger.info("Ongoing call status: " + str(call_status))

            else:
                raise ScriptFail("## Emergency call not started")

            # End call
            ui2.click_with_resource_id_exists(dut, "com.google.android.dialer:id/incall_end_call")
            self.logger.info("Call end : ")
            time.sleep(5)

        if asserttip.get_assert_state(dut) is True:
            raise ScriptFail("Red screen assertion found in dut")

    # def cleanup_iteration(self):
    #     """ Cleanup every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def cleanup_testcase(self):
        """ Cleanup every testcase executes

        :return:
        """
        ui2.click_with_resource_id_exists(dut, "com.google.android.dialer:id/incall_end_call")
        self.logger.info("Call end : ")
        time.sleep(5)

        lib.forget_all_saved_wifi(dut)
        lib.forget_all_saved_wifi(aux2)

        lib.close_hotspot(aux2)
        time.sleep(2)

        if wifi.is_wifi_opened(dut) is True:
            wifi.close_wifi(dut)

        # clear red screen
        if asserttip.get_assert_state(dut) is True:
            asserttip.clear_assert_red(dut)

        common.press_home_key(dut)
        time.sleep(2)
        common.clear_background_apps(dut, "all")

        common.press_home_key(aux)
        time.sleep(1)
        common.clear_background_apps(aux, "all")

        common.press_home_key(aux2)
        time.sleep(2)
        common.clear_background_apps(aux2, "all")


if __name__ == '__main__':
    tc = Network_033()
    tc.execute()
