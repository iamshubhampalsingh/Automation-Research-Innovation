#!/usr/bin/env python
# -*- coding: utf-8 -*-
# coding=utf-8

# ------------------------------------------------------------
# Copyright (C), 2008-2018, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2018-2019, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2019-2020, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2020-2021, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2021-2022, OPPO Mobile Comm Corp., Ltd.
# ------------------------------------------------------------
# Author: Shubham Pal Singh(shubham.singh@oppo.com)
# ------------------------------------------------------------

import time
from olib_aw.base import TcBase
from olib_aw.base import bluetooth, common
from olib_aw.teams.test_ui import ui_commont_ as ui2
from olib_aw.base import ScriptFail
from olib_scripts.libs.oplus_india import Library_SDcard_CONN as lib # pylint:disable=import-error
from olib_aw.utils import set_as_tc


@set_as_tc(
    project_name='India_SDcardSolution_test',
    script_desc="""
    Transfer and receive files through bluetooth and oppo share.
    """,
    author='Shubham Pal Singh (IN009359)',
    created_time='2022/02/25',
    modified_time='2022/06/01',
    modified_desc=""" """,
    pre_condition="""
    * initialize_testcase:
    * initialize_iteration
    """,
    test_steps="""
    *  Turn on BT of DUT and Auxillary device
    *  Try To Send Any Files from Auxillary device to DUT through BT"

    """,
    post_condition="""
    * cleanup_iteration
    * cleanup_testcase    
    """,
    expection_result="""
    * File Should receive properly and Save in Internal storage.
    """,
    topology_dependencies=3,
    devices_tags=[["phoneDUT", "phoneSUT"]]
)
class Connectivity_BT_003(TcBase):
    """ This is the TC template class

    """

    def initialize_testcase(self):
        """ Initialize before every testcase executes

        :return:
        """
        global dut
        dut = self.topology.get_phone(label="phoneDUT")
        self.exception_all = []

        global aux
        aux = self.topology.get_phone(label="phoneSUT")
        self.exception_all = []

    # def initialize_iteration(self):
    #     """ Initialize before every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def main(self):
        # Turn off Bluetooth in SD card in dut
        lib.SDcard_bluetooth(dut, 0)
        time.sleep(2)

        # Open quick settings in dut
        if bluetooth.is_opened(dut) is False:
            res = bluetooth.open_bluetooth(dut)
            self.logger.info("Bluetooth is ON in dut : " + str(res))
            time.sleep(2)

        # Open quick settings in aux
        if bluetooth.is_opened(aux) is False:
            res = bluetooth.open_bluetooth(aux)
            self.logger.info("Bluetooth is ON in aux : " + str(res))
            time.sleep(2)

        # Click Image with camera app
        lib.click_image(aux)
        self.logger.info("Image Clicked in aux")
        time.sleep(4)

        # Get the dut device bluetooth name
        dut_device_name = lib.get_device_bt_name(dut)
        self.logger.info("dut bluetooth name is : " + dut_device_name)
        time.sleep(2)

        send_image_name = lib.get_clicked_image_filename(aux)
        self.logger.info("Image to be send is in aux : " + send_image_name)
        time.sleep(2)

        # send file from aux
        lib.send_via_bt(aux, send_image_name, dut_device_name)
        time.sleep(2)

        # dut receive process start
        ui2.click_with_resource_id_exists(dut, "android:id/button1")
        self.logger.info("Clicked on Accept in dut")
        time.sleep(30)

        receive_image_status = lib.get_image_file_status_internal_bt(dut, send_image_name)
        self.logger.info("Received image status is : {}".format(receive_image_status))
        time.sleep(2)

        if receive_image_status:
            self.logger.info("PASS : the images name match and exists in the phone storage")
        else:
            raise ScriptFail("No file in phone storage")

        # check for red screen
        lib.check_red_screen(dut, aux)

    # def cleanup_iteration(self):
    #     """ Cleanup every iteration executes
    #
    #     :return:
    #     """

    def cleanup_testcase(self):
        """ Cleanup every testcase executes

        :return:
        """
        # check for red screen
        lib.clear_red_screen(dut, aux)

        bluetooth.close_bluetooth(dut)
        bluetooth.close_bluetooth(aux)

        common.press_home_key(dut)
        time.sleep(2)
        common.clear_background_apps(dut, "all")

        common.press_home_key(aux)
        time.sleep(2)
        common.clear_background_apps(aux, "all")


if __name__ == '__main__':
    tc = Connectivity_BT_003()
    tc.execute()
