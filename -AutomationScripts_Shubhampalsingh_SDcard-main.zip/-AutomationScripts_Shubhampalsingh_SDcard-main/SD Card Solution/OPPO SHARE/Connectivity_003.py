#!/usr/bin/env python
# -*- coding: utf-8 -*-
# coding=utf-8

# ------------------------------------------------------------
# Copyright (C), 2008-2018, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2018-2019, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2019-2020, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2020-2021, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2021-2022, OPPO Mobile Comm Corp., Ltd.
# ------------------------------------------------------------
# Author: Shubham Pal Singh(shubham.singh@oppo.com)
# ------------------------------------------------------------


import time
from olib_aw.base import TcBase
from olib_aw.base import bluetooth, common
from olib_aw.base import ScriptFail
from olib_scripts.libs.oplus_india import Library_SDcard_CONN as lib # pylint:disable=import-error
from olib_aw.utils import set_as_tc


@set_as_tc(
    project_name='India_SDcardSolution_test',
    script_desc="""
    Transfer and receive files through bluetooth and oppo share.
    """,
    author='Shubham Pal Singh (IN009359)',
    created_time='2022/02/25',
    modified_time='2022/06/01',
    modified_desc=""" """,
    pre_condition="""
    * initialize_testcase:
    * initialize_iteration
    """,
    test_steps="""
    *  Turn on opposhare of DUT and Auxillary device
    *  Try To Send Any Files from Auxillary device to DUT through opposhare"

    """,
    post_condition="""
    * cleanup_iteration
    * cleanup_testcase    
    """,
    expection_result="""
    *  File Should receive properly and Save in Internal storage

    """,
    topology_dependencies=3,
    devices_tags=[["phoneDUT", "phoneSUT"]]
)
class Connectivity_003(TcBase):
    """ This is the TC template class

    """
    def initialize_testcase(self):
        """ Initialize before every testcase executes

        :return:
        """
        global dut
        dut = self.topology.get_phone(label="phoneDUT")
        self.exception_all = []

        global aux
        aux = self.topology.get_phone(label="phoneSUT")
        self.exception_all = []

    # def initialize_iteration(self):
    #     """ Initialize before every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def main(self):
        # Turn on oppo_share in SD card in dut
        lib.SDcard_oppo_share(dut,0)

        # Open quick settings in dut
        if bluetooth.get_oppo_share_state(dut) is False:
            lib.turn_on_oppo_share(dut)

        # Open quick settings in aux
        if bluetooth.get_oppo_share_state(aux) is False:
            lib.turn_on_oppo_share(aux)

        # click image in aux
        lib.click_image(aux)
        self.logger.info("Click Image in aux : ")
        time.sleep(3)

        send_image_name = lib.get_clicked_image_filename(aux)
        self.logger.info("Image to be send is : " + send_image_name)
        time.sleep(2)

        # send image from aux
        lib.send_via_oppo_share(aux, send_image_name)

        # receive image in dut
        lib.receive_incoming_file(dut)

        receive_image_status = lib.get_image_file_status_internal_os(dut, send_image_name)
        self.logger.info("Received image status is : {}".format(receive_image_status))
        time.sleep(2)

        if receive_image_status:
            self.logger.info("PASS : the images name match and exists in the Phone Storage")
        else:
            raise ScriptFail("No file in Phone Storage")

        # check for red screen
        lib.check_red_screen(dut, aux)

    # def cleanup_iteration(self):
    #     """ Cleanup every iteration executes
    #
    #     :return:
    #     """

    def cleanup_testcase(self):
        """ Cleanup every testcase executes

        :return:
        """
        lib.clear_red_screen(dut, aux)

        lib.SDcard_oppo_share(dut,0)
        time.sleep(4)

        common.press_home_key(dut)
        time.sleep(2)
        common.clear_background_apps(dut, "all")

        common.press_home_key(aux)
        time.sleep(2)
        common.clear_background_apps(aux, "all")


if __name__ == '__main__':
    tc = Connectivity_003()
    tc.execute()
