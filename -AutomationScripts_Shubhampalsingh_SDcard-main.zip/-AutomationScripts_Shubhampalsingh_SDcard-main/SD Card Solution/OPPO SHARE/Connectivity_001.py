#!/usr/bin/env python
# -*- coding: utf-8 -*-
# coding=utf-8

# ------------------------------------------------------------
# Copyright (C), 2008-2018, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2018-2019, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2019-2020, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2020-2021, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2021-2022, OPPO Mobile Comm Corp., Ltd.
# ------------------------------------------------------------
# Author: Shubham Pal Singh(shubham.singh@oppo.com)
# ------------------------------------------------------------


import time
from olib_aw.base import TcBase
from olib_aw.teams.test_ui import ui_commont_ as ui2
from olib_aw.base import ScriptFail, common
from olib_scripts.libs.oplus_india import Library_SDcard_CONN as lib # pylint:disable=import-error
from olib_aw.utils import set_as_tc


@set_as_tc(
    project_name='India_SDcardSolution_test',
    script_desc="""
    Transfer and receive files through bluetooth and oppo share.
    """,
    author='Shubham Pal Singh (IN009359)',
    created_time='2022/02/25',
    modified_time='2022/06/01',
    modified_desc=""" """,
    pre_condition="""
    * initialize_testcase:
    * initialize_iteration
    """,
    test_steps="""
    *  Open The SDcard Solution Page
    *  Turn on and Off Toggle opposhare Button"

    """,
    post_condition="""
    * cleanup_iteration
    * cleanup_testcase    
    """,
    expection_result="""
    *  Should be Turn on and Off Normally

    """,
    topology_dependencies=3,
    devices_tags=[["phoneDUT", "phoneSUT"]]
)
class Connectivity_001(TcBase):
    """ This is the TC template class

    """

    def initialize_testcase(self):
        """ Initialize before every testcase executes

        :return:
        """
        global dut
        dut = self.topology.get_phone(label="phoneDUT")
        self.exception_all = []

        global aux
        aux = self.topology.get_phone(label="phoneSUT")
        self.exception_all = []

    # def initialize_iteration(self):
    #     """ Initialize before every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def main(self):

        # Open Settings
        lib.navigate_to_oppo_share(dut)

        # Turn on OPPO Share if not checked
        if ui2.check_exists_Text(dut, "Camera") is True:
            if dut.phoneui2(className = "android.widget.Switch")[4].info.get("checked") is True:
                dut.phoneui2(className="android.widget.Switch")[4].click()
                time.sleep(2)
                if dut.phoneui2(className = "android.widget.Switch")[4].info.get("checked") is True:
                    raise ScriptFail("Toggle switch is not working properly")
                dut.phoneui2(className="android.widget.Switch")[4].click()
                time.sleep(3)
                if dut.phoneui2(className = "android.widget.Switch")[4].info.get("checked") is False:
                    raise ScriptFail("Toggle switch is not working properly")

            else:
                dut.phoneui2(className="android.widget.Switch")[4].click()
                time.sleep(2)
                if dut.phoneui2(className = "android.widget.Switch")[4].info.get("checked") is False:
                    raise ScriptFail("Toggle switch is not working properly")
                dut.phoneui2(className="android.widget.Switch")[4].click()
                time.sleep(2)
                if dut.phoneui2(className = "android.widget.Switch")[4].info.get("checked") is True:
                    raise ScriptFail("Toggle switch is not working properly")

        else:
            if dut.phoneui2(className = "android.widget.Switch")[3].info.get("checked") is True:
                dut.phoneui2(className="android.widget.Switch")[3].click()
                time.sleep(2)
                if dut.phoneui2(className = "android.widget.Switch")[3].info.get("checked") is True:
                    raise ScriptFail("Toggle switch is not working properly")
                dut.phoneui2(className="android.widget.Switch")[3].click()
                time.sleep(2)
                if dut.phoneui2(className = "android.widget.Switch")[3].info.get("checked") is False:
                    raise ScriptFail("Toggle switch is not working properly")

            else:
                dut.phoneui2(className="android.widget.Switch")[3].click()
                time.sleep(2)
                if dut.phoneui2(className = "android.widget.Switch")[3].info.get("checked") is False:
                    raise ScriptFail("Toggle switch is not working properly")
                dut.phoneui2(className="android.widget.Switch")[3].click()
                time.sleep(2)
                if dut.phoneui2(className = "android.widget.Switch")[3].info.get("checked") is True:
                    raise ScriptFail("Toggle switch is not working properly")

        self.logger.info("Toggle switch is working properly")

        # check for red screen
        lib.check_red_screen(dut, aux)

    # def cleanup_iteration(self):
    #     """ Cleanup every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def cleanup_testcase(self):
        """ Cleanup every testcase executes

        :return:
        """
        # check for red screen
        lib.clear_red_screen(dut, aux)

        common.press_home_key(dut)
        time.sleep(2)
        common.clear_background_apps(dut, "all")

        common.press_home_key(aux)
        time.sleep(2)
        common.clear_background_apps(aux, "all")


if __name__ == '__main__':
    tc = Connectivity_001()
    tc.execute()
