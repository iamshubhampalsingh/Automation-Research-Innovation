#!/usr/bin/env python
# -*- coding: utf-8 -*-
# coding=utf-8

# ------------------------------------------------------------
# Copyright (C), 2008-2018, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2018-2019, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2019-2020, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2020-2021, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2021-2022, OPPO Mobile Comm Corp., Ltd.
# ------------------------------------------------------------
# Author: Shubham Pal Singh(shubham.singh@oppo.com)
# ------------------------------------------------------------

import time
from olib_aw.base import TcBase
from olib_aw.base import settings, ui
from olib_aw.base import common, asserttip
from olib_aw.teams.test_ui import ui_commont_ as ui2
from olib_scripts.libs.oplus_india import Library_conn as lib # pylint:disable=import-error
from olib_aw.base import ScriptFail
from olib_aw.utils import set_as_tc


@set_as_tc(
    project_name='India_Connectivity_test',
    script_desc="""
    Wi-Fi, BT and NFC tests.
    """,
    author='Shubham Pal Singh(IN009359)',
    created_time='2022/08/25',
    modified_time='2022/08/25',
    modified_desc=""" """,
    pre_condition="""
    * initialize_testcase:
    * initialize_iteration
    """,
    test_steps="""
    *   1. Rename device name in Wifi direct settings.
    *   2. Reboot DUT
    *   3. Check DUT name after rebooting device in auxillary device

    """,
    post_condition="""
    * cleanup_iteration
    * cleanup_testcase    
    """,
    expection_result="""
    *   Auxillary device should display modified name.

    """,
    topology_dependencies=3,
    devices_tags=[["phoneDUT"], ["phoneSUT"]]
)
class Wi_Fi_005_0100(TcBase):
    """ This is the TC template class

    """

    def initialize_testcase(self):
        """ Initialize before every testcase executes

        :return:
        """
        global dut
        dut = self.topology.get_phone(label="phoneDUT")
        self.exception_all = []

        global aux
        aux = self.topology.get_phone(label="phoneSUT")
        self.exception_all = []

    # def initialize_iteration(self):
    #     """ Initialize before every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def main(self):
        settings.set_system_language(dut, "en", "IN")

        # Open wifi direct Settings
        lib.open_wifi_direct(dut)
        res = ui2.click_with_text(dut, "Device name")
        self.logger.info("clicked on device name: {}".format(res))
        time.sleep(2)

        # rename DUT
        ui.text_clear(dut)
        time.sleep(2)
        name = "TEST_DUT"
        ui.text_direct_input(dut, name)
        time.sleep(2)
        ui2.click_with_resource_id_exists(dut, "android:id/button1")
        time.sleep(2)

        # reboot DUT
        lib.reboot_device(dut)

        lib.open_wifi_direct(dut)
        lib.open_wifi_direct(aux)
        time.sleep(15)

        # check dut name in auxillary device
        if ui2.check_exists_Text(aux, name):
            self.logger.info("Modified name visible in auxillary device: PASS")
        else:
            raise ScriptFail("Modified name not found in auxillary device")

        # check RSA
        if asserttip.get_assert_state(dut) is True:
            raise ScriptFail("Red screen assertion found in dut")

    # def cleanup_iteration(self):
    #     """ Cleanup every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def cleanup_testcase(self):
        """ Cleanup every testcase executes

        :return:
        """
        # clear red screen
        if asserttip.get_assert_state(dut) is True:
            asserttip.clear_assert_red(dut)

        common.press_home_key(dut)
        time.sleep(2)
        common.clear_background_apps(dut, "all")
        common.press_home_key(aux)
        time.sleep(2)
        common.clear_background_apps(aux, "all")


if __name__ == '__main__':
    tc = Wi_Fi_005_0100()
    tc.execute()
