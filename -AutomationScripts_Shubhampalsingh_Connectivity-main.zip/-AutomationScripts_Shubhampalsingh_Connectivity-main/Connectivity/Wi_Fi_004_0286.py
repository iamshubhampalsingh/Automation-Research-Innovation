#!/usr/bin/env python
# -*- coding: utf-8 -*-
# coding=utf-8

# ------------------------------------------------------------
# Copyright (C), 2008-2018, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2018-2019, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2019-2020, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2020-2021, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2021-2022, OPPO Mobile Comm Corp., Ltd.
# ------------------------------------------------------------
# Author: Shubham Pal Singh(Shubham.singh@oppo.com)
# ------------------------------------------------------------

import time
from olib_aw.base import TcBase
from olib_aw.base import settings, network
from olib_aw.base import common, asserttip
from olib_aw.teams.test_ui import ui_commont_ as ui2
from olib_scripts.libs.oplus_india import Library_network as lib_net # pylint:disable=import-error
from olib_aw.base import ScriptFail, PreconditionsException
from olib_aw.utils import set_as_tc


@set_as_tc(
    project_name='India_Connectivity_test',
    script_desc="""
    Wi-Fi, BT and NFC tests.
    """,
    author='Shubham Pal Singh (IN009359)',
    created_time='2022/08/25',
    modified_time='2022/08/25',
    modified_desc=""" """,
    pre_condition="""
    * initialize_testcase: "1. Insert JIO in slot-1.
    2. Data is enabled."
    * initialize_iteration
    """,
    test_steps="""
    *   1. Open dial pad
    *   2. Dial *#*#4636#*#*>> Wi-Fi information.
    *   3. Select Wi-Fi API and observe.
    *   4. Observed in device wireless settings assert while trying to access Wi-Fi API.

    """,
    post_condition="""
    * cleanup_iteration
    * cleanup_testcase    
    """,
    expection_result="""
    *   No such assert should be observed while accessing Wi-Fi API.
    """,
    topology_dependencies=3,
    devices_tags=[["phoneDUT"]]
)
class Wi_Fi_004_0286(TcBase):
    """ This is the TC template class

    """

    def initialize_testcase(self):
        """ Initialize before every testcase executes

        :return:
        """
        global dut
        dut = self.topology.get_phone(label="phoneDUT")
        self.exception_all = []

    # def initialize_iteration(self):
    #     """ Initialize before every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def main(self):
        settings.set_system_language(dut, "en", "IN")

        # check for Jio sim
        if lib_net.check_operator_name_slot_1(dut) == "Jio 4G":
            self.logger.info("Jio sim found in slot1")
            network.open_data_network(dut)
            time.sleep(2)
        else:
            raise PreconditionsException("JIO sim not found: NA")

        # dial *#*#4636#*#*
        res = common.start_app_activity(dut, "com.google.android.dialer", "com.google.android.dialer.extensions.GoogleDialtactsActivity")
        self.logger.info("Google dialer open : " + str(res))
        time.sleep(2)
        ui2.click_with_resource_id_exists(dut, "com.google.android.dialer:id/dialpad_fab")
        time.sleep(2)

        res = common.exec_shell_command(dut, 'input text "*#*#4636#*#*"')
        self.logger.info("USSD number *#*#4636#*#* dialed : " + str(res))
        time.sleep(5)

        # open wifi info
        res = ui2.click_with_text(dut, "Wi-Fi information")
        self.logger.info("Wi-fi information clicked: " + str(res))
        time.sleep(5)
        if ui2.click_with_text(dut, "Wi-Fi API"):
            self.logger.info("Wi-fi API clicked")
            time.sleep(5)
        else:
            raise PreconditionsException("Wi-Fi API not found/navigation failed")

        # check RSA
        if asserttip.get_assert_state(dut) is True:
            raise ScriptFail("Red screen assertion found in dut")
        else:
            self.logger.info("No RSA found in Wi-Fi API: PASS")

    # def cleanup_iteration(self):
    #     """ Cleanup every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def cleanup_testcase(self):
        """ Cleanup every testcase executes

        :return:
        """
        # clear red screen
        if asserttip.get_assert_state(dut) is True:
            asserttip.clear_assert_red(dut)

        common.press_home_key(dut)
        time.sleep(2)
        common.clear_background_apps(dut, "all")


if __name__ == '__main__':
    tc = Wi_Fi_004_0286()
    tc.execute()
