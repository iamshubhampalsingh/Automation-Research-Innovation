#!/usr/bin/env python
# -*- coding: utf-8 -*-
# coding=utf-8

# ------------------------------------------------------------
# Copyright (C), 2008-2018, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2018-2019, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2019-2020, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2020-2021, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2021-2022, OPPO Mobile Comm Corp., Ltd.
# ------------------------------------------------------------
# Author: Shubham Pal Singh(shubham.singh@oppo.com)
# ------------------------------------------------------------

import time
from olib_aw.base import TcBase
from olib_aw.base import settings, bluetooth
from olib_aw.base import common, asserttip
from olib_aw.teams.test_ui import ui_commont_ as ui2
from olib_scripts.libs.oplus_india import Library_SDcard_CONN as lib_sd # pylint:disable=import-error
from olib_aw.base import ScriptFail
from olib_aw.utils import set_as_tc


@set_as_tc(
    project_name='India_Connectivity_test',
    script_desc="""
    Wi-Fi, BT and NFC tests.
    """,
    author= 'Shubham Pal Singh('IN009359')',
    created_time='2022/08/25',
    modified_time='2022/08/25',
    modified_desc=""" """,
    pre_condition="""
    * initialize_testcase: "1. Insert JIO in slot-1.
    2. Data is enabled."
    * initialize_iteration
    """,
    test_steps="""
    *   1. Turn Bluetooth and receive some files from another device (any files)
    *   2. After successfully received files, open QS panel and click on Received notifications3.
    *   3. From Inbound Window click on the file and check for pop up window

    """,
    post_condition="""
    * cleanup_iteration
    * cleanup_testcase    
    """,
    expection_result="""
    *   Bluetooth:  should not be Inbound Files Window
    """,
    topology_dependencies=3,
    devices_tags=[["phoneDUT"], ["phoneSUT"]]
)
class Bluetooth_002_0065(TcBase):
    """ This is the TC template class

    """

    def initialize_testcase(self):
        """ Initialize before every testcase executes

        :return:
        """
        global dut
        dut = self.topology.get_phone(label="phoneDUT")
        self.exception_all = []

        global aux
        aux = self.topology.get_phone(label="phoneSUT")
        self.exception_all = []

    # def initialize_iteration(self):
    #     """ Initialize before every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def main(self):
        settings.set_system_language(dut, "en", "IN")

        # turn on BT and receive file
        if bluetooth.is_opened(dut) is False:
            res = bluetooth.open_bluetooth(dut)
            self.logger.info("Bluetooth is ON in dut : " + str(res))

        # Open quick settings in aux
        if bluetooth.is_opened(aux) is False:
            res = bluetooth.open_bluetooth(aux)
            self.logger.info("Bluetooth is ON in aux : " + str(res))

        # Click Image with camera app
        lib_sd.click_image(aux)
        self.logger.info("Image Clicked in aux")
        time.sleep(5)

        # Get the dut device bluetooth name
        dut_device_name = lib_sd.get_device_bt_name(dut)
        self.logger.info("dut bluetooth name is : " + dut_device_name)
        time.sleep(2)

        send_image_name = lib_sd.get_clicked_image_filename(aux)
        self.logger.info("Image to be send is in aux: " + send_image_name)
        time.sleep(2)

        # send file from aux
        lib_sd.send_via_bt(aux, send_image_name, dut_device_name)

        # receive file in dut
        ui2.click_with_resource_id_exists(dut, "android:id/button1")
        self.logger.info("Clicked on Accept in dut")
        time.sleep(60)
        common.press_home_key(dut)
        time.sleep(2)

        # open received file from notification
        ui2.open_notification(dut)
        time.sleep(2)
        if dut.phoneui2(resourceId='android:id/app_name_text', text="Bluetooth").exists():
            self.logger.info("Bluetooth notification found")
            time.sleep(5)
            dut.phoneui2(resourceId='android:id/app_name_text', text="Bluetooth").click()
            self.logger.info("Bluetooth notification clicked")
            time.sleep(2)
        else:
            ui2.scroll_up(dut)
            if dut.phoneui2(resourceId='android:id/app_name_text', text="Bluetooth").exists():
                self.logger.info("Bluetooth notification found")
                time.sleep(5)
                dut.phoneui2(resourceId='android:id/app_name_text', text="Bluetooth").click()
                self.logger.info("Bluetooth notification clicked")
                time.sleep(2)
            else:
                raise ScriptFail("Bluetooth transfer notification not found")

        if common.is_activity_exist(dut, "com.android.bluetooth", "com.android.bluetooth.opp.OplusBluetoothOppTransferHistory"):
            self.logger.info("inbound transfer page open: PASS")
            if ui2.check_exists_Text(dut, send_image_name) or ui2.scroll_to_find(dut, send_image_name):
                self.logger.info("Image received successfully: PASS")
            else:
                raise ScriptFail("Image not received")
        else:
            raise ScriptFail("inbound transfer page not open")

        # check RSA
        if asserttip.get_assert_state(dut) is True:
            raise ScriptFail("Red screen assertion found in dut")

    # def cleanup_iteration(self):
    #     """ Cleanup every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def cleanup_testcase(self):
        """ Cleanup every testcase executes

        :return:
        """
        # clear red screen
        if asserttip.get_assert_state(dut) is True:
            asserttip.clear_assert_red(dut)

        common.press_home_key(dut)
        time.sleep(2)
        common.clear_background_apps(dut, "all")

        common.press_home_key(aux)
        time.sleep(2)
        common.clear_background_apps(aux, "all")


if __name__ == '__main__':
    tc = Bluetooth_002_0065()
    tc.execute()
    
