#!/usr/bin/env python
# -*- coding: utf-8 -*-
# coding=utf-8

# ------------------------------------------------------------
# Copyright (C), 2008-2018, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2018-2019, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2019-2020, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2020-2021, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2021-2022, OPPO Mobile Comm Corp., Ltd.
# ------------------------------------------------------------
# Author: Shubham Pal Singh(shubham.singh@oppo.com)
# ------------------------------------------------------------

import time
from olib_aw.base import TcBase
from olib_aw.base import settings, network, sim
from olib_aw.base import common, asserttip
from olib_aw.teams.test_ui import ui_commont_ as ui2
from olib_scripts.libs.oplus_india import Library_conn as lib # pylint:disable=import-error
from olib_aw.base import ScriptFail, PreconditionsException
from olib_aw.utils import set_as_tc


@set_as_tc(
    project_name='India_Connectivity_test',
    script_desc="""
    Wi-Fi, BT and NFC tests.
    """,
    author='Shubham Pal Singh (IN009359)',
    created_time='2022/08/25',
    modified_time='2022/08/25',
    modified_desc=""" """,
    pre_condition="""
    * initialize_testcase:
    * initialize_iteration
    """,
    test_steps="""
    *   1.Open settings
    *   2.Open Connection and Sharing.
    *   3.Open personal hotspot
    *   4.Open personal hotspot Settings
    *   5.Change the security to WPA 3 PSK
    *   6.Come back to personal hotspot ui
    *   7.Turn on personal hotspot.
    *   8.Observe Duts behaviour"

    """,
    post_condition="""
    * cleanup_iteration
    * cleanup_testcase    
    """,
    expection_result="""
    * Dut should be  able to turn on personal hotspot when WPA3 PSK is selected as security
    """,
    topology_dependencies=3,
    devices_tags=[["phoneDUT"]]
)
class Wi_Fi_005_0097(TcBase):
    """ This is the TC template class

    """

    def initialize_testcase(self):
        """ Initialize before every testcase executes

        :return:
        """
        global dut
        dut = self.topology.get_phone(label="phoneDUT")
        self.exception_all = []

    # def initialize_iteration(self):
    #     """ Initialize before every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def main(self):
        settings.set_system_language(dut, "en", "IN")
        if sim.is_existed(dut, simid=0):
            network.open_data_network(dut)
        else:
            raise PreconditionsException("No sim card in DUT")

        # turn on hotspot from settings
        lib.open_hotspot_ui(dut)

        # open hotspot settings
        res = ui2.click_with_text(dut, "Hotspot settings")
        self.logger.info("Hotspot settings clicked:" + str(res))
        time.sleep(2)
        res = ui2.click_with_text(dut, "Security")
        self.logger.info("Security clicked:" + str(res))
        time.sleep(2)
        res = ui2.click_with_text(dut, "WPA3-Personal")
        self.logger.info("WPA3-Personal clicked:" + str(res))
        time.sleep(2)
        ui2.click_with_resource_id_exists(dut, "com.oplus.wirelesssettings:id/menu_save")
        time.sleep(2)
        if dut.phoneui2(className="android.widget.Switch")[0].info.get("checked") is False:
            raise ScriptFail("Hotspot not turned ON in WPA3 security")
        else:
            self.logger.info("Hotspot turned ON in WPA3 security: PASS")

        if asserttip.get_assert_state(dut) is True:
            raise ScriptFail("Red screen assertion found in dut")

    # def cleanup_iteration(self):
    #     """ Cleanup every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def cleanup_testcase(self):
        """ Cleanup every testcase executes

        :return:
        """
        lib.close_hotspot(dut)

        # clear red screen
        if asserttip.get_assert_state(dut) is True:
            asserttip.clear_assert_red(dut)

        common.press_home_key(dut)
        time.sleep(2)
        common.clear_background_apps(dut, "all")


if __name__ == '__main__':
    tc = Wi_Fi_005_0097()
    tc.execute()
