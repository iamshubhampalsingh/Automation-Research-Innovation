#!/usr/bin/env python
# -*- coding: utf-8 -*-
# coding=utf-8

# ------------------------------------------------------------
# Copyright (C), 2008-2018, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2018-2019, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2019-2020, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2020-2021, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2021-2022, OPPO Mobile Comm Corp., Ltd.
# ------------------------------------------------------------
# Author: Shubham Pal Singh(shubham.singh@oppo.com)
# ------------------------------------------------------------

import time
from olib_aw.base import TcBase, ui
from olib_aw.base import settings, network, sim
from olib_aw.base import common, asserttip
from olib_aw.teams.test_ui import ui_commont_ as ui2
from olib_scripts.libs.oplus_india import Library_conn as lib # pylint:disable=import-error
from olib_aw.base import ScriptFail, PreconditionsException
from olib_aw.utils import set_as_tc


@set_as_tc(
    project_name='India_Connectivity_test',
    script_desc="""
    Wi-Fi, BT and NFC tests.
    """,
    author='Shubham Pal Singh(IN009359)',
    created_time='2022/08/25',
    modified_time='2022/08/25',
    modified_desc=""" """,
    pre_condition="""
    * initialize_testcase:
    * initialize_iteration
    """,
    test_steps="""
    *   1. Open Settings
    *   2.Open Connection and sharing
    *   3.Open Personal hotspot & Turn on
    *   4.Change the name of personal hotspot to a single double quotation mark("")
    *   5.Come back to Personal hotspot UI
    *   6.Turn on HOTSPOT
    *   7.Tap on QR code.
    *   8. Observe DUT.

    """,
    post_condition="""
    * cleanup_iteration
    * cleanup_testcase    
    """,
    expection_result="""
    *   1.Dut can Open Settings
    *   2.Dut can Open Connection and sharing
    *   3.Dut can Open Personal hotspot & Turn on
    *   4.Dut can Change the name of personal hotspot to a single double quotation mark("")
    *   7.Dut opens the QR CODE generator
    *   8.DUT should not show ""WirelessSettings keeps stopping"" error pop-up in Personal Hotspot and redscreen assertion

    """,
    topology_dependencies=3,
    devices_tags=[["phoneDUT"]]
)
class Wi_Fi_005_0099(TcBase):
    """ This is the TC template class

    """

    def initialize_testcase(self):
        """ Initialize before every testcase executes

        :return:
        """
        global dut
        dut = self.topology.get_phone(label="phoneDUT")
        self.exception_all = []

    # def initialize_iteration(self):
    #     """ Initialize before every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def main(self):
        settings.set_system_language(dut, "en", "IN")
        if sim.is_existed(dut, simid=0):
            network.open_data_network(dut)
        else:
            raise PreconditionsException("No sim card in DUT")
        # turn on hotspot from settings
        lib.open_hotspot_ui(dut)

        # open hotspot settings
        res = ui2.click_with_text(dut, "Hotspot settings")
        self.logger.info("Hotspot settings clicked:" + str(res))
        time.sleep(2)
        ui2.click_with_resource_id_exists(dut, "com.oplus.wirelesssettings:id/edittext_container")
        time.sleep(2)
        ui.text_clear(dut)
        dut.phoneui2(className="android.widget.EditText").set_text('"')
        time.sleep(2)
        ui2.click_with_resource_id_exists(dut, "com.oplus.wirelesssettings:id/menu_save")
        time.sleep(2)
        if dut.phoneui2(className="android.widget.Switch")[0].info.get("checked") is False:
            raise ScriptFail("Hotspot not turned ON after name change")
        else:
            self.logger.info("Hotspot turned ON after name change: PASS")

        # open QR code
        ui2.click_with_resource_id_exists(dut, "com.oplus.wirelesssettings:id/qricon")
        time.sleep(2)
        if ui2.check_exists_resource_id(dut, "com.oplus.wirelesssettings:id/qr_code_img"):
            self.logger.info("QR code open: PASS")
            time.sleep(2)
            common.press_back_key(dut)
        else:
            raise ScriptFail("QR code failed to open")

        # check hotspot page open
        if common.is_activity_exist(dut, "com.oplus.wirelesssettings", "com.android.settings.SettingsActivity"):
            self.logger.info("Personal hotspot page active : PASS")
            time.sleep(2)
        else:
            raise ScriptFail("Personal hotspot page crashed")

        if asserttip.get_assert_state(dut) is True:
            raise ScriptFail("Red screen assertion found in dut")

    # def cleanup_iteration(self):
    #     """ Cleanup every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def cleanup_testcase(self):
        """ Cleanup every testcase executes

        :return:
        """
        lib.reset_network_settings(dut)

        lib.close_hotspot(dut)

        # clear red screen
        if asserttip.get_assert_state(dut) is True:
            asserttip.clear_assert_red(dut)

        common.press_home_key(dut)
        time.sleep(2)
        common.clear_background_apps(dut, "all")


if __name__ == '__main__':
    tc = Wi_Fi_005_0099()
    tc.execute()
