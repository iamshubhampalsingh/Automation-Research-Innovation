#!/usr/bin/env python
# -*- coding: utf-8 -*-
# coding=utf-8

# ------------------------------------------------------------
# Copyright (C), 2008-2018, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2018-2019, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2019-2020, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2020-2021, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2021-2022, OPPO Mobile Comm Corp., Ltd.
# ------------------------------------------------------------
# Author:Shubham Pal Singh(Shubham.singh@oppo.com)
# ------------------------------------------------------------

import time
from olib_aw.base import TcBase
from olib_aw.base import settings, wifi
from olib_aw.base import common, asserttip
from olib_aw.teams.test_ui import ui_commont_ as ui2
from olib_scripts.libs.oplus_india import Library_conn as lib # pylint:disable=import-error
from olib_aw.base import ScriptFail
from olib_aw.utils import set_as_tc


@set_as_tc(
    project_name='India_Connectivity_test',
    script_desc="""
    Wi-Fi, BT and NFC tests.
    """,
    author='Shubham Pal Singh (IN009359)',
    created_time='2022/08/25',
    modified_time='2022/08/25',
    modified_desc=""" """,
    pre_condition="""
    * initialize_testcase:
    * initialize_iteration
    """,
    test_steps="""
    *   1.Open Setting
    *   2.Open Wi-Fi
    *   3.Open MANUALLY ADD NETWORK
    *   4.Select security :-WAPI PSK
    *   5.Select TYPE 
    *   6.TURN ON/OFF Dark mode.
    *   7.Select the WAPI hexadecimal.
    *   8.Observe the DUT Behavior.

    """,
    post_condition="""
    * cleanup_iteration
    * cleanup_testcase    
    """,
    expection_result="""
    *   DUT should not show "Wireless Settings keeps stopping" error pop-up in MANUALLY ADD NETWORK and red screen assertion.

    """,
    topology_dependencies=3,
    devices_tags=[["phoneDUT"]]
)
class Wi_Fi_004_0282(TcBase):
    """ This is the TC template class

    """

    def initialize_testcase(self):
        """ Initialize before every testcase executes

        :return:
        """
        global dut
        dut = self.topology.get_phone(label="phoneDUT")
        self.exception_all = []

    # def initialize_iteration(self):
    #     """ Initialize before every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def main(self):
        settings.set_system_language(dut, "en", "IN")
        wifi.open_wifi(dut)
        settings.close_dark_mode(dut)

        # Open wifi Settings
        lib.open_add_wifi_ui(dut)
        lib.select_security_wapi_psk_type(dut)

        # turn on/off dark mode
        settings.open_dark_mode(dut)
        time.sleep(2)

        if asserttip.get_assert_state(dut) is True:
            raise ScriptFail("Red screen assertion found in dut in dark mode")

        settings.close_dark_mode(dut)
        time.sleep(2)

        if asserttip.get_assert_state(dut) is True:
            raise ScriptFail("Red screen assertion found in dut in light mode")

        lib.select_security_wapi_psk_type(dut)
        res = ui2.click_with_text(dut, "WAPI hexadecimal")
        self.logger.info("clicked on WAPI hexadecimal: {}".format(res))
        time.sleep(2)

        # check app running
        if common.is_apk_running(dut, "com.oplus.wirelesssettings"):
            self.logger.info("No crash or RSA observed: PASS")
        else:
            raise ScriptFail("Wifi settings crashed")

    # def cleanup_iteration(self):
    #     """ Cleanup every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def cleanup_testcase(self):
        """ Cleanup every testcase executes

        :return:
        """
        # clear red screen
        if asserttip.get_assert_state(dut) is True:
            asserttip.clear_assert_red(dut)

        settings.close_dark_mode(dut)
        common.press_home_key(dut)
        time.sleep(2)
        common.clear_background_apps(dut, "all")


if __name__ == '__main__':
    tc = Wi_Fi_004_0282()
    tc.execute()
