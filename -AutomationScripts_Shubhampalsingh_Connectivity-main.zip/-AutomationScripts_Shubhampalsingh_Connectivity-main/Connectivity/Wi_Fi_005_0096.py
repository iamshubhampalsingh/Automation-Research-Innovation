#!/usr/bin/env python
# -*- coding: utf-8 -*-
# coding=utf-8

# ------------------------------------------------------------
# Copyright (C), 2008-2018, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2018-2019, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2019-2020, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2020-2021, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2021-2022, OPPO Mobile Comm Corp., Ltd.
# ------------------------------------------------------------
# Author: Shubham Pal Singh(shubham.singh@oppo.com)
# ------------------------------------------------------------

import time
from olib_aw.base import TcBase, ui
from olib_aw.base import settings, network, sim
from olib_aw.base import common, asserttip
from olib_aw.teams.test_ui import ui_commont_ as ui2
from olib_scripts.libs.oplus_india import Library_conn as lib # pylint:disable=import-error
from olib_aw.base import ScriptFail, PreconditionsException
from olib_aw.utils import set_as_tc


@set_as_tc(
    project_name='India_Connectivity_test',
    script_desc="""
    Wi-Fi, BT and NFC tests.
    """,
    author='Shubham Pal Singh (IN009359)',
    created_time='2022/08/25',
    modified_time='2022/08/25',
    modified_desc=""" """,
    pre_condition="""
    * initialize_testcase: 1.Duts should have at least one sim 
    2.Dut should be connected to wifi and Mobile data  should be  turned on .

    * initialize_iteration
    """,
    test_steps="""
    *   1.Open settings
    *   2.Open Connection and Sharing.
    *   3.Open personal hotspot
    *   4.Turn on Personal hotspot.
    *   5.Press Home Button
    *   6.Drag down notification bar
    *   7.Press on WIFI-TETHERING POP-UP
    *   8.Observe DUTS behaviour"

    """,
    post_condition="""
    * cleanup_iteration
    * cleanup_testcase    
    """,
    expection_result="""
    *   Dut Should be able to enter the WIFI-TETHERING settings from notification bar WIFI-TETHERING POP-UP
    """,
    topology_dependencies=3,
    devices_tags=[["phoneDUT"], ["phoneSUT"]]
)
class Wi_Fi_005_0096(TcBase):
    """ This is the TC template class

    """

    def initialize_testcase(self):
        """ Initialize before every testcase executes

        :return:
        """
        global dut
        dut = self.topology.get_phone(label="phoneDUT")
        self.exception_all = []

        global aux
        aux = self.topology.get_phone(label="phoneSUT")
        self.exception_all = []

    # def initialize_iteration(self):
    #     """ Initialize before every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def main(self):
        settings.set_system_language(dut, "en", "IN")
        if sim.is_existed(dut, simid=0):
            network.open_data_network(dut)
        else:
            raise PreconditionsException("No sim card in DUT")
        # connect DUT to wifi
        lib.create_hotspot(aux)
        lib.connect_to_wifi_hotspot(dut)

        # turn on hotspot from settings
        lib.open_hotspot_ui(dut)
        common.press_home_key(dut)
        time.sleep(2)

        # open notification panel
        ui2.open_quick_settings(dut)
        time.sleep(2)
        if dut.phoneui2(className='androidx.viewpager.widget.ViewPager'):
            left = dut.phoneui2(className='androidx.viewpager.widget.ViewPager')[0].info.get('bounds').get('left')
            right = dut.phoneui2(className='androidx.viewpager.widget.ViewPager')[0].info.get('bounds').get('right')
            top = dut.phoneui2(className='androidx.viewpager.widget.ViewPager')[0].info.get('bounds').get('top')
            bottom = dut.phoneui2(className='androidx.viewpager.widget.ViewPager')[0].info.get('bounds').get('bottom')
            vertical_mid = int((top + bottom) / 2)
            horizontal_mid = int((right + left) / 2)

        else:
            left = dut.phoneui2(className='com.oplusos.systemui.qs.widget.ViewPager')[0].info.get('bounds').get('left')
            right = dut.phoneui2(className='com.oplusos.systemui.qs.widget.ViewPager')[0].info.get('bounds').get(
                'right')
            top = dut.phoneui2(className='com.oplusos.systemui.qs.widget.ViewPager')[0].info.get('bounds').get('top')
            bottom = dut.phoneui2(className='com.oplusos.systemui.qs.widget.ViewPager')[0].info.get('bounds').get(
                'bottom')
            vertical_mid = int((top + bottom) / 2)
            horizontal_mid = int((right + left) / 2)

        count = 0
        while (count < 3 and not ui2.check_exists_description(dut, "Hotspot")):
            ui.screen_simple_swipe(dut, horizontal_mid, vertical_mid, left, vertical_mid)
            count = count + 1

        if ui2.check_exists_description(dut, "Hotspot"):
            self.logger.info("Found hotspot button")
            dut.phoneui2(description='Hotspot').long_click(duration=100)
            time.sleep(2)
            res = ui2.click_with_text(dut, "MORE")
            self.logger.info("MORE clicked:" + str(res))
            time.sleep(2)

            # check hotspot page open
            if ui2.check_exists_Text(dut, "Personal hotspot") and common.is_activity_exist(dut, "com.oplus.wirelesssettings", "com.android.settings.SettingsActivity"):
                self.logger.info("Personal hotspot page open : PASS")
            else:
                raise ScriptFail("Personal hotspot page failed to open")

        if asserttip.get_assert_state(dut) is True:
            raise ScriptFail("Red screen assertion found in dut")

    # def cleanup_iteration(self):
    #     """ Cleanup every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def cleanup_testcase(self):
        """ Cleanup every testcase executes

        :return:
        """
        lib.close_hotspot(dut)
        lib.close_hotspot(aux)

        # clear red screen
        if asserttip.get_assert_state(dut) is True:
            asserttip.clear_assert_red(dut)

        common.press_home_key(dut)
        time.sleep(2)
        common.clear_background_apps(dut, "all")

        common.press_home_key(aux)
        time.sleep(2)
        common.clear_background_apps(aux, "all")


if __name__ == '__main__':
    tc = Wi_Fi_005_0096()
    tc.execute()
