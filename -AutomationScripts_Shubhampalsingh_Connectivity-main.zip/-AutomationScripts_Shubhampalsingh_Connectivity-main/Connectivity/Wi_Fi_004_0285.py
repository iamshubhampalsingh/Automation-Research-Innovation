#!/usr/bin/env python
# -*- coding: utf-8 -*-
# coding=utf-8

# ------------------------------------------------------------
# Copyright (C), 2008-2018, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2018-2019, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2019-2020, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2020-2021, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2021-2022, OPPO Mobile Comm Corp., Ltd.
# ------------------------------------------------------------
# Author: Shubham Pal Singh(shubham.singh@oppo.com)
# ------------------------------------------------------------

import time
from olib_aw.base import TcBase
from olib_aw.base import settings
from olib_aw.base import common, asserttip
from olib_aw.teams.test_ui import ui_commont_ as ui2
from olib_scripts.libs.oplus_india import Library_conn as lib # pylint:disable=import-error
from olib_aw.base import ScriptFail
from olib_aw.utils import set_as_tc


@set_as_tc(
    project_name='India_Connectivity_test',
    script_desc="""
    Wi-Fi, BT and NFC tests.
    """,
    author='Shubham Pal Singh (IN009359)',
    created_time='2022/08/25',
    modified_time='2022/08/25',
    modified_desc=""" """,
    pre_condition="""
    * initialize_testcase:
    * initialize_iteration
    """,
    test_steps="""
    *   1.open settings
    *   2.open connection & sharing
    *   3.Open VPN 
    *   4.Click on ""+""on top-right corner.
    *   5.Open VPN type
    *   6.Select L2TP/IP sec RSA
    *   7.Click on IPSec User Certificate
    *   8.Turn ON/OFF Dark mode
    *   9.Select the IPSec User Certificate
    *   10.observe the DUT Behaviour.

    """,
    post_condition="""
    * cleanup_iteration
    * cleanup_testcase    
    """,
    expection_result="""
    *   DUT shows RED SCREEN ASSERTION in VPN & wireless settings keeps stopping pop-up.
    """,
    topology_dependencies=3,
    devices_tags=[["phoneDUT"]]
)
class Wi_Fi_004_0285(TcBase):
    """ This is the TC template class

    """

    def initialize_testcase(self):
        """ Initialize before every testcase executes

        :return:
        """
        global dut
        dut = self.topology.get_phone(label="phoneDUT")
        self.exception_all = []

    # def initialize_iteration(self):
    #     """ Initialize before every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def main(self):
        settings.set_system_language(dut, "en", "IN")

        # open VPN settings
        lib.open_vpn_ui(dut)
        ui2.click_with_xpath(dut, '//androidx.appcompat.widget.LinearLayoutCompat')
        time.sleep(2)
        res = ui2.click_with_text(dut, "VPN type")
        self.logger.info("clicked on VPN type: {}".format(res))
        time.sleep(2)
        res = ui2.click_with_text(dut, "IKEv2/IPSec RSA")
        self.logger.info("clicked on IKEv2/IPSec RSA: {}".format(res))
        time.sleep(2)
        res = ui2.click_with_text(dut, "IPSec User Certificate")
        self.logger.info("clicked on IPSec User Certificate: {}".format(res))
        time.sleep(2)

        # turn on/off dark mode
        settings.open_dark_mode(dut)
        time.sleep(2)
        if asserttip.get_assert_state(dut) is True:
            raise ScriptFail("Red screen assertion found in dut in dark mode")

        settings.close_dark_mode(dut)
        time.sleep(2)
        if asserttip.get_assert_state(dut) is True:
            raise ScriptFail("Red screen assertion found in dut in light mode")

        if common.is_apk_running(dut, "com.oplus.wirelesssettings"):
            self.logger.info("No RSA or app crash observed: PASS")
        else:
            raise ScriptFail("VPN settings page crashed")

    # def cleanup_iteration(self):
    #     """ Cleanup every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def cleanup_testcase(self):
        """ Cleanup every testcase executes

        :return:
        """
        # clear red screen
        if asserttip.get_assert_state(dut) is True:
            asserttip.clear_assert_red(dut)

        common.press_home_key(dut)
        time.sleep(2)
        common.clear_background_apps(dut, "all")


if __name__ == '__main__':
    tc = Wi_Fi_004_0285()
    tc.execute()
