#!/usr/bin/env python
# -*- coding: utf-8 -*-
# coding=utf-8

# ------------------------------------------------------------
# Copyright (C), 2008-2018, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2018-2019, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2019-2020, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2020-2021, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2021-2022, OPPO Mobile Comm Corp., Ltd.
# ------------------------------------------------------------
# Author: Akesh Srivastava(akesh.srivastava@oppo.com)
# ------------------------------------------------------------

import time
from olib_aw.base import TcBase
from olib_aw.base import common, asserttip
from olib_aw.base import ScriptFail
from olib_scripts.libs.oplus_india import Library_camera as lib # pylint:disable=import-error
from olib_aw.utils import set_as_tc


@set_as_tc(
    project_name='India_Camera_test',
    script_desc="""
    Camera settings and feature test.
    """,
    author='Akesh Srivastava (IN009394)',
    created_time='2022/02/25',
    modified_time='2022/06/01',
    modified_desc=""" """,
    pre_condition="""
    * initialize_testcase:
    * initialize_iteration
    """,
    test_steps="""
    *  Long press camera app for shortcuts
    *  click on shortcut: Remove

    """,
    post_condition="""
    * cleanup_iteration
    * cleanup_testcase    
    """,
    expection_result="""
    *   camera settings and features should be present and can be used.
    """,
    topology_dependencies=1,
    devices_tags=[["phoneDUT"]]
)
class sanity_shortcut_remove(TcBase):
    """ This is the TC template class

    """

    def initialize_testcase(self):
        """ Initialize before every testcase executes

        :return:
        """
        global dut

        dut = self.topology.get_phone(label="phoneDUT")
        self.exception_all = []

    # def initialize_iteration(self):
    #     """ Initialize before every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def main(self):
        u = dut.phoneui2

        result_arr = []  # Array to store all the return pass or fail values ,at the end this would be used to pass or fail the test case

        # Remove part
        common.app_initialization(dut, "com.oplus.camera")
        u(description="Camera").long_click()
        time.sleep(2)
        u.xpath('//*[@content-desc="Remove"]').click()
        time.sleep(3)
        result_arr.append(u.xpath('//*[@resource-id="com.android.launcher:id/txt_uninstall_main_title"]').exists)
        time.sleep(3)
        u.press("back")

        print(result_arr)
        output = True  # By default we assume test case is pass
        for item in result_arr:
            if item != True:  # IF any item was not true,then we are considering it as a fail and then break
                output = False
                break

        # CSV to give ui type output for  testing team
        List = ["sanity_shortcuts",
                "Check for Remove Result:", output]
        lib.to_csv(List)

        if (output == False):
            raise ScriptFail('Element not found')

        # check RSA
        if asserttip.get_assert_state(dut) is True:
            raise ScriptFail("Red screen assertion found in dut")

    # def cleanup_iteration(self):
    #
    #     pass

    def cleanup_testcase(self):
        lib.cleanup_camera(dut)


if __name__ == '__main__':
    tc = sanity_shortcut_remove()
    tc.execute()
