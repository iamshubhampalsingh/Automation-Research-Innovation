#!/usr/bin/env python
# -*- coding: utf-8 -*-
# coding=utf-8

# ------------------------------------------------------------
# Copyright (C), 2008-2018, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2018-2019, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2019-2020, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2020-2021, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2021-2022, OPPO Mobile Comm Corp., Ltd.
# ------------------------------------------------------------
# Author: Shubham Pal Singh(shubham.singh@oppo.com)
# ------------------------------------------------------------

import time
from olib_aw.base import TcBase
from olib_aw.base import common, asserttip
from olib_aw.teams.test_ui import ui_commont_ as ui2
from olib_aw.base import ScriptFail
from olib_scripts.libs.oplus_india import Library_camera as lib # pylint:disable=import-error
from olib_aw.utils import set_as_tc


@set_as_tc(
    project_name='India_Camera_localization_test',
    script_desc="""
    Check applied personalization color on camera UI.
    """,
    author='Shubham Pal Singh (IN009359)',
    created_time='2022/08/08',
    modified_time='2022/08/08',
    modified_desc=""" """,
    pre_condition="""
    * initialize_testcase:
    * initialize_iteration
    """,
    test_steps="""
    *   1. Enter the photo mode (rear) 
    *   2. Mobile phone to view the preview, and then take a photo, view thumbnails and photos 
    *   3. Switch to the photo mode (front), repeat step 1"

    """,
    post_condition="""
    * cleanup_iteration
    * cleanup_testcase    
    """,
    expection_result="""
    *   1. The preview is smooth during the movement, and there is no delay with the actual scene.
    *   2. The thumbnail is consistent with the preview content, the photo is consistent with the preview.
    *   3. Switching should be normal from rear to front without any delay and abnormal behavior."

    """,
    topology_dependencies=1,
    devices_tags=[["phoneDUT"]]
)
class IN_CameraSanity_001_001(TcBase):
    """ This is the TC template class

    """

    def initialize_testcase(self):
        """ Initialize before every testcase executes

        :return:
        """
        global dut
        dut = self.topology.get_phone(label="phoneDUT")
        self.exception_all = []

    # def initialize_iteration(self):
    #     """ Initialize before every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def main(self):
        # open camera
        lib.launch_camera(dut)

        # check image capture in PHOTO mode rear
        self.logger.info("checking in PHOTO mode rear")

        if lib.click_check(dut):
            self.logger.info("Image captured and saved in rear photo mode: PASS")
        else:
            raise ScriptFail("Image capture and save failed")
        ui2.click_with_resource_id_exists(dut, "com.oplus.camera:id/thumbnail")
        time.sleep(2)
        common.press_back_key(dut)
        time.sleep(2)

        # check image capture in PHOTO mode front
        ui2.click_with_resource_id_exists(dut, "com.oplus.camera:id/switch_camera_button")
        self.logger.info("checking in PHOTO mode front")

        if lib.click_check(dut):
            self.logger.info("Image captured and saved in rear photo mode: PASS")
        else:
            raise ScriptFail("Image capture and save failed")
        ui2.click_with_resource_id_exists(dut, "com.oplus.camera:id/thumbnail")
        time.sleep(2)

        if asserttip.get_assert_state(dut) is True:
            raise ScriptFail("Red screen assertion found in dut")

    # def cleanup_iteration(self):
    #     """ Cleanup every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def cleanup_testcase(self):
        """ Cleanup every testcase executes

        :return:
        """
        # clear red screen
        if asserttip.get_assert_state(dut) is True:
            asserttip.clear_assert_red(dut)
        common.press_home_key(dut)
        time.sleep(2)
        common.clear_background_apps(dut, "all")


if __name__ == '__main__':
    tc = IN_CameraSanity_001_001()
    tc.execute()
