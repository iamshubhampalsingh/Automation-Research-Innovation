#!/usr/bin/env python
# -*- coding: utf-8 -*-
# coding=utf-8

# ------------------------------------------------------------
# Copyright (C), 2008-2018, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2018-2019, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2019-2020, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2020-2021, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2021-2022, OPPO Mobile Comm Corp., Ltd.
# ------------------------------------------------------------
# Author: Akesh Srivastava(akesh.srivastava@oppo.com)
# ------------------------------------------------------------

import time
from olib_aw.base import TcBase
from olib_aw.base import common, asserttip
from olib_aw.teams.test_ui import ui_commont_ as ui2
from olib_aw.base import ScriptFail
from olib_aw.utils import set_as_tc
from olib_scripts.libs.oplus_india import Library_camera as lib # pylint:disable=import-error


@set_as_tc(
    project_name='India_Camera_localization_test',
    script_desc="""
    Check applied personalization color on camera UI.
    """,
    author='Akesh Srivastava (IN009394)',
    created_time='2022/08/08',
    modified_time='2022/08/08',
    modified_desc=""" """,
    pre_condition="""
    * initialize_testcase:
    * initialize_iteration
    """,
    test_steps="""
    *   1.Settings>Privacy>Camera access>Turn Off or Add Camera access shortcut to control center and Turn off
    *   2.Open camera and observe

    """,
    post_condition="""
    * cleanup_iteration
    * cleanup_testcase    
    """,
    expection_result="""
    *   "Unblock device camera" pop upshould not  disappears within 1 sec after turning off camera access.
    (Issue Reference : 3154005)

    """,
    topology_dependencies=1,
    devices_tags=[["phoneDUT"]]
)
class IN_Exploratory_001_039(TcBase):
    """ This is the TC template class

    """

    def initialize_testcase(self):
        """ Initialize before every testcase executes

        :return:
        """
        global dut
        dut = self.topology.get_phone(label="phoneDUT")
        self.exception_all = []

    # def initialize_iteration(self):
    #     """ Initialize before every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def main(self):
        # turn off camera access
        common.start_app_activity(dut, "com.android.settings", "com.android.settings.Settings")
        time.sleep(2)

        res = ui2.scroll_to_find(dut, "Privacy")
        self.logger.info("Scroll to find Privacy: {}".format(res))
        time.sleep(2)

        res = ui2.click_with_text(dut, "Privacy")
        self.logger.info("Click on Privacy: {}".format(res))
        time.sleep(2)

        if dut.phoneui2(className="android.widget.Switch")[0].info.get("checked") is True:
            dut.phoneui2(className="android.widget.Switch")[0].click()
            time.sleep(2)
        self.logger.info("Camera access turned OFF")
        common.press_home_key(dut)

        # open camera
        lib.launch_camera(dut)

        # check for unblock pop-up
        if ui2.check_exists_Text(dut, "Unblock"):
            self.logger.info("Unblock pop-up exists: PASS")
            time.sleep(2)
        else:
            raise ScriptFail("Unblock pop-up not found: FAIL")

        # check RSA
        if asserttip.get_assert_state(dut) is True:
            raise ScriptFail("Red screen assertion found in dut")

    # def cleanup_iteration(self):
    #     """ Cleanup every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def cleanup_testcase(self):
        """ Cleanup every testcase executes

        :return:
        """
        # turn on camera access
        if ui2.check_exists_Text(dut, "Unblock"):
            ui2.click_with_text(dut, "Unblock")
            time.sleep(2)
        else:
            common.press_home_key(dut)
            common.start_app_activity(dut, "com.android.settings", "com.android.settings.Settings")
            time.sleep(2)

            res = ui2.scroll_to_find(dut, "Privacy")
            self.logger.info("Scroll to find Privacy: {}".format(res))
            time.sleep(2)

            res = ui2.click_with_text(dut, "Privacy")
            self.logger.info("Click on Privacy: {}".format(res))
            time.sleep(2)

            if dut.phoneui2(className="android.widget.Switch")[0].info.get("checked") is not True:
                dut.phoneui2(className="android.widget.Switch")[0].click()
                time.sleep(2)

        # clear red screen
        if asserttip.get_assert_state(dut) is True:
            asserttip.clear_assert_red(dut)

        common.press_home_key(dut)
        time.sleep(2)
        common.clear_background_apps(dut, "all")


if __name__ == '__main__':
    tc = IN_Exploratory_001_039()
    tc.execute()
