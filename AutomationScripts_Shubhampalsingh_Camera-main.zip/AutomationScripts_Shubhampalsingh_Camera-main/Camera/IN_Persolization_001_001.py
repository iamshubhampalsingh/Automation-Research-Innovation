#!/usr/bin/env python
# -*- coding: utf-8 -*-
# coding=utf-8

# ------------------------------------------------------------
# Copyright (C), 2008-2018, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2018-2019, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2019-2020, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2020-2021, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2021-2022, OPPO Mobile Comm Corp., Ltd.
# ------------------------------------------------------------
# Author: Akesh Srivastava(akesh.srivastava@oppo.com)
# ------------------------------------------------------------

import time
from olib_aw.base import TcBase
from olib_aw.base import common, asserttip
from olib_aw.base import ScriptFail, PreconditionsException
from olib_aw.utils import set_as_tc
from olib_scripts.libs.oplus_india import Library_camera as lib # pylint:disable=import-error
from olib_scripts.libs.oplus_india import Library_personalization as lib_per # pylint:disable=import-error


@set_as_tc(
    project_name='India_Camera_localization_test',
    script_desc="""
    Check applied personalization color on camera UI.
    """,
    author='Akesh Srivastava (IN009394)',
    created_time='2022/08/08',
    modified_time='2022/08/08',
    modified_desc=""" """,
    pre_condition="""
    * initialize_testcase:
    * initialize_iteration
    """,
    test_steps="""
    *   1. Open the camera
    *   2. Switch each camera mode
    *   3. Check the color display of each tab poge

    """,
    post_condition="""
    * cleanup_iteration
    * cleanup_testcase    
    """,
    expection_result="""
    *   1. Camera should be open properly
    *   2. Each camera mode should be open without any abnormal behavior
    *   3. The color style of each page of the camera changes according to the color set in the Personalization"

    """,
    topology_dependencies=1,
    devices_tags=[["phoneDUT"]]
)
class IN_Persolization_001_001(TcBase):
    """ This is the TC template class

    """

    def initialize_testcase(self):
        """ Initialize before every testcase executes

        :return:
        """
        global dut
        dut = self.topology.get_phone(label="phoneDUT")
        self.exception_all = []

    # def initialize_iteration(self):
    #     """ Initialize before every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def main(self):
        # apply color
        applied_color = lib_per.apply_a_monotheme_color(dut)
        common.press_home_key(dut)

        # open camera
        lib.launch_camera(dut)
        if lib.open_camera_settings(dut):
            self.logger.info("Camera settings open: PASS")
        else:
            raise ScriptFail("Camera settings failed to open")

        osversion = common.exec_shell_command(dut, "getprop ro.build.version.release")
        self.logger.info("OS version is: {}".format(osversion))
        time.sleep(2)
        osversion1 = osversion.strip()

        if osversion1 == "13":
            raise PreconditionsException("Camera app not adapted to Personalization colors: By design")

        if lib_per.verify_color_match(dut, "com.oplus.camera:id/assignment", applied_color):
            self.logger.info("Settings text applied to selected color: PASS")
        else:
            raise ScriptFail("Monocolor not applied")

        if lib_per.verify_color_match_single(dut, dut.phoneui2(resourceId='android:id/switch_widget')[1], applied_color):
            self.logger.info("Settings radio button applied to selected color: PASS")
        else:
            raise ScriptFail("Monocolor not applied")

        # check RSA
        if asserttip.get_assert_state(dut) is True:
            raise ScriptFail("Red screen assertion found in dut")

    # def cleanup_iteration(self):
    #     """ Cleanup every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def cleanup_testcase(self):
        """ Cleanup every testcase executes

        :return:
        """
        lib.cleanup_camera(dut)


if __name__ == '__main__':
    tc = IN_Persolization_001_001()
    tc.execute()
