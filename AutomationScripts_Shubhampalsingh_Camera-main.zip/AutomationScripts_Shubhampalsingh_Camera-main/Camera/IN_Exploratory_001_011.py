#!/usr/bin/env python
# -*- coding: utf-8 -*-
# coding=utf-8

# ------------------------------------------------------------
# Copyright (C), 2008-2018, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2018-2019, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2019-2020, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2020-2021, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2021-2022, OPPO Mobile Comm Corp., Ltd.
# ------------------------------------------------------------
# Author: Akesh Srivastava(akesh.srivastava@oppo.com)
# ------------------------------------------------------------

import time
from olib_aw.base import TcBase
from olib_aw.base import common, asserttip
from olib_aw.teams.test_ui import ui_commont_ as ui2
from olib_aw.base import ScriptFail
from olib_scripts.libs.oplus_india import Library_camera as lib # pylint:disable=import-error
from olib_aw.utils import set_as_tc


@set_as_tc(
    project_name='India_Camera_localization_test',
    script_desc="""
    Check applied personalization color on camera UI.
    """,
    author='Akesh Srivastava (IN009394)',
    created_time='2022/08/08',
    modified_time='2022/08/08',
    modified_desc=""" """,
    pre_condition="""
    * initialize_testcase:
    * initialize_iteration
    """,
    test_steps="""
    *   1. Open camera and take a picture In each mode
    *   2. Check the thumbnail after clicking
    *   3. Open a picture through thumbnail
    *   4. check the image"

    """,
    post_condition="""
    * cleanup_iteration
    * cleanup_testcase    
    """,
    expection_result="""
    *   1. Camera should open properly in every mode of camera
    *   2. Thumbnail should open without any delay and and image should open without black screen, blur, RSA etc.
    *   3. Thumbnail and other options should not overlap to each other."

    """,
    topology_dependencies=1,
    devices_tags=[["phoneDUT"]]
)
class IN_Exploratory_001_011(TcBase):
    """ This is the TC template class

    """

    def initialize_testcase(self):
        """ Initialize before every testcase executes

        :return:
        """
        global dut
        dut = self.topology.get_phone(label="phoneDUT")
        self.exception_all = []

    # def initialize_iteration(self):
    #     """ Initialize before every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def main(self):
        # open camera
        lib.launch_camera(dut)

        # check in PHOTO mode
        self.logger.info("checking in PHOTO mode")
        if lib.click_check(dut) is False:
            raise ScriptFail("Image failed to click and save")
        else:
            self.logger.info("Image clicked and saved: PASS")

        ui2.click_with_resource_id_exists(dut, "com.oplus.camera:id/thumbnail")
        time.sleep(3)
        res = common.is_activity_exist(dut, "com.coloros.gallery3d", "com.oppo.gallery3d.app.ViewGallery")
        self.logger.info("Image opened from thumbnail: {}".format(res))
        if res is False:
            raise ScriptFail("Image failed to open from thumbnail")
        common.press_back_key(dut)
        time.sleep(5)

        # check in NIGHT mode
        dut.phoneui2.swipe_ext("right")
        dut.phoneui2.swipe_ext("right")
        time.sleep(2)
        self.logger.info("checking in NIGHT mode")
        if lib.click_check(dut) is False:
            raise ScriptFail("Image failed to click and save")
        else:
            self.logger.info("Image clicked and saved: PASS")

        ui2.click_with_resource_id_exists(dut, "com.oplus.camera:id/thumbnail")
        time.sleep(3)
        res = common.is_activity_exist(dut, "com.coloros.gallery3d", "com.oppo.gallery3d.app.ViewGallery")
        self.logger.info("Image opened from thumbnail: {}".format(res))
        if res is False:
            raise ScriptFail("Image failed to open from thumbnail")
        common.press_back_key(dut)
        time.sleep(5)

        # check in PORTRAIT mode
        dut.phoneui2.swipe_ext("left")
        dut.phoneui2.swipe_ext("left")
        dut.phoneui2.swipe_ext("left")
        time.sleep(2)
        self.logger.info("checking in PORTRAIT mode")
        if lib.click_check(dut) is False:
            raise ScriptFail("Image failed to click and save")
        else:
            self.logger.info("Image clicked and saved: PASS")

        ui2.click_with_resource_id_exists(dut, "com.oplus.camera:id/thumbnail")
        time.sleep(3)
        res = common.is_activity_exist(dut, "com.coloros.gallery3d", "com.oppo.gallery3d.app.ViewGallery")
        self.logger.info("Image opened from thumbnail: {}".format(res))
        if res is False:
            raise ScriptFail("Image failed to open from thumbnail")
        common.press_back_key(dut)
        time.sleep(5)

        # check in PRO mode
        dut.phoneui2.swipe_ext("left")
        time.sleep(2)
        ui2.click_with_description_exists(dut, "PRO", timeout=2)
        self.logger.info("checking in PRO mode")
        if lib.click_check(dut) is False:
            raise ScriptFail("Image failed to click and save")
        else:
            self.logger.info("Image clicked and saved: PASS")
            time.sleep(2)

        ui2.click_with_resource_id_exists(dut, "com.oplus.camera:id/thumbnail")
        time.sleep(3)
        res = common.is_activity_exist(dut, "com.coloros.gallery3d", "com.oppo.gallery3d.app.ViewGallery")
        self.logger.info("Image opened from thumbnail: {}".format(res))
        if res is False:
            raise ScriptFail("Image failed to open from thumbnail")
        common.press_back_key(dut)
        time.sleep(5)

        # check in EXTRA_HD mode
        ui2.click_with_resource_id_exists(dut, "com.oplus.camera:id/mode_close")
        dut.phoneui2.swipe_ext("left")
        time.sleep(2)
        ui2.click_with_description_exists(dut, "EXTRA HD", timeout=2)
        self.logger.info("checking in EXTRA HD mode")
        if lib.click_check(dut) is False:
            raise ScriptFail("Image failed to click and save")
        else:
            self.logger.info("Image clicked and saved: PASS")

        ui2.click_with_resource_id_exists(dut, "com.oplus.camera:id/thumbnail")
        time.sleep(3)
        res = common.is_activity_exist(dut, "com.coloros.gallery3d", "com.oppo.gallery3d.app.ViewGallery")
        self.logger.info("Image opened from thumbnail: {}".format(res))
        if res is False:
            raise ScriptFail("Image failed to open from thumbnail")
        common.press_back_key(dut)
        time.sleep(5)

        # check in MACRO mode
        ui2.click_with_resource_id_exists(dut, "com.oplus.camera:id/mode_close")
        dut.phoneui2.swipe_ext("left")
        time.sleep(2)
        ui2.click_with_description_exists(dut, "MACRO", timeout=2)
        self.logger.info("checking in MACRO mode")
        if lib.click_check(dut) is False:
            raise ScriptFail("Image failed to click and save")
        else:
            self.logger.info("Image clicked and saved: PASS")

        ui2.click_with_resource_id_exists(dut, "com.oplus.camera:id/thumbnail")
        time.sleep(2)
        res = common.is_activity_exist(dut, "com.coloros.gallery3d", "com.oppo.gallery3d.app.ViewGallery")
        self.logger.info("Image opened from thumbnail: {}".format(res))
        if res is False:
            raise ScriptFail("Image failed to open from thumbnail")
        common.press_back_key(dut)
        time.sleep(5)

        # check in STICKER mode
        ui2.click_with_resource_id_exists(dut, "com.oplus.camera:id/mode_close")
        dut.phoneui2.swipe_ext("left")
        time.sleep(2)
        ui2.click_with_description_exists(dut, "STICKER", timeout=2)
        self.logger.info("checking in STICKER mode")
        if lib.click_check(dut) is False:
            raise ScriptFail("Image failed to click and save")
        else:
            self.logger.info("Image clicked and saved: PASS")

        ui2.click_with_resource_id_exists(dut, "com.oplus.camera:id/thumbnail")
        time.sleep(4)
        res = common.is_activity_exist(dut, "com.coloros.gallery3d", "com.oppo.gallery3d.app.ViewGallery")
        self.logger.info("Image opened from thumbnail: {}".format(res))
        if res is False:
            raise ScriptFail("Image failed to open from thumbnail")
        common.press_back_key(dut)
        time.sleep(5)

        # check in TEXT SCANNER mode
        ui2.click_with_resource_id_exists(dut, "com.oplus.camera:id/mode_close")
        dut.phoneui2.swipe_ext("left")
        time.sleep(2)
        ui2.click_with_description_exists(dut, "TEXT SCANNER", timeout=2)
        self.logger.info("checking in TEXT SCANNER mode")
        if lib.click_check(dut) is False:
            raise ScriptFail("Image failed to click and save")
        else:
            self.logger.info("Image clicked and saved: PASS")

        ui2.click_with_resource_id_exists(dut, "com.oplus.camera:id/thumbnail")
        time.sleep(3)
        res = common.is_activity_exist(dut, "com.coloros.gallery3d", "com.oppo.gallery3d.app.ViewGallery")
        self.logger.info("Image opened from thumbnail: {}".format(res))
        if res is False:
            raise ScriptFail("Image failed to open from thumbnail")
        common.press_back_key(dut)
        time.sleep(5)

        # check RSA
        if asserttip.get_assert_state(dut) is True:
            raise ScriptFail("Red screen assertion found in dut")

    # def cleanup_iteration(self):
    #     """ Cleanup every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def cleanup_testcase(self):
        """ Cleanup every testcase executes

        :return:
        """
        # clear red screen
        if asserttip.get_assert_state(dut) is True:
            asserttip.clear_assert_red(dut)
        common.press_home_key(dut)
        time.sleep(2)
        common.clear_background_apps(dut, "all")


if __name__ == '__main__':
    tc = IN_Exploratory_001_011()
    tc.execute()
