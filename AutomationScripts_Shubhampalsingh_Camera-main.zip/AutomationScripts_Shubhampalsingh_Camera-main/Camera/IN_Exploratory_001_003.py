#!/usr/bin/env python
# -*- coding: utf-8 -*-
# coding=utf-8

# ------------------------------------------------------------
# Copyright (C), 2008-2018, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2018-2019, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2019-2020, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2020-2021, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2021-2022, OPPO Mobile Comm Corp., Ltd.
# ------------------------------------------------------------
# Author: Shubham Pal Singh(shubham.singh@oppo.com)
# ------------------------------------------------------------

import time
from olib_aw.base import TcBase
from olib_aw.base import common, asserttip
from olib_aw.teams.test_ui import ui_commont_ as ui2
from olib_aw.base import ScriptFail
from olib_scripts.libs.oplus_india import Library_camera as lib # pylint:disable=import-error
from olib_aw.utils import set_as_tc


@set_as_tc(
    project_name='India_Camera_localization_test',
    script_desc="""
    Check applied personalization color on camera UI.
    """,
    author='Shubham Pal Singh (IN009359)',
    created_time='2022/08/08',
    modified_time='2022/08/08',
    modified_desc=""" """,
    pre_condition="""
    * initialize_testcase:
    * initialize_iteration
    """,
    test_steps="""
    *   1. Open camera
    *   2. Go to settings > Volume button
    *   3. Set volume button as Zoom
    *   4. Set zoom volume by setting volume button 
    *   5. Click picture in all modes and check

    """,
    post_condition="""
    * cleanup_iteration
    * cleanup_testcase    
    """,
    expection_result="""
    *   1. Camera should be open properly
    *   2. Camera settings should be open properly without abnormal behavior
    *   3. Click a picture with volume button without any abnormal behavior, camera crash, UI abnormality, RSA etc.
    *   4. Zoom value should be set properly with volume button without any crash and black screen.
    *   5. Click an picture and check the behavior any abnormal behavior, camera crash, UI abnormality, RSA etc.

    """,
    topology_dependencies=1,
    devices_tags=[["phoneDUT"]]
)
class IN_Exploratory_001_003(TcBase):
    """ This is the TC template class

    """

    def initialize_testcase(self):
        """ Initialize before every testcase executes

        :return:
        """
        global dut
        dut = self.topology.get_phone(label="phoneDUT")
        self.exception_all = []

    # def initialize_iteration(self):
    #     """ Initialize before every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def main(self):
        # open camera
        lib.launch_camera(dut)

        # check image capture with volume as zoom in PHOTO mode
        self.logger.info("checking in PHOTO mode")
        lib.check_volumeAction_zoom(dut)

        # check image capture with volume as zoom in NIGHT mode
        dut.phoneui2.swipe_ext("right")
        dut.phoneui2.swipe_ext("right")
        self.logger.info("checking in NIGHT mode")
        lib.check_volumeAction_zoom(dut)

        # check image capture with volume as zoom in PRO mode
        dut.phoneui2.swipe_ext("left")
        dut.phoneui2.swipe_ext("left")
        dut.phoneui2.swipe_ext("left")
        dut.phoneui2.swipe_ext("left")
        time.sleep(2)
        ui2.click_with_description_exists(dut, "PRO", timeout=2)
        self.logger.info("checking in PRO mode")
        lib.check_volumeAction_zoom(dut)

        # check image capture with volume as zoom in EXTRA_HD mode
        ui2.click_with_resource_id_exists(dut, "com.oplus.camera:id/mode_close")
        dut.phoneui2.swipe_ext("left")
        time.sleep(2)
        ui2.click_with_description_exists(dut, "EXTRA HD", timeout=2)
        self.logger.info("checking in EXTRA HD mode")
        lib.check_volumeAction_zoom(dut)

        # check image capture with volume as zoom in MACRO mode
        ui2.click_with_resource_id_exists(dut, "com.oplus.camera:id/mode_close")
        dut.phoneui2.swipe_ext("left")
        time.sleep(2)
        ui2.click_with_description_exists(dut, "MACRO", timeout=2)
        self.logger.info("checking in MACRO mode")
        lib.check_volumeAction_zoom(dut)

        # check image capture with volume as zoom in STICKER mode
        ui2.click_with_resource_id_exists(dut, "com.oplus.camera:id/mode_close")
        dut.phoneui2.swipe_ext("left")
        time.sleep(2)
        ui2.click_with_description_exists(dut, "STICKER", timeout=2)
        self.logger.info("checking in STICKER mode")
        lib.check_volumeAction_zoom(dut)

        # check image capture with volume as zoom in TEXT SCANNER mode
        ui2.click_with_resource_id_exists(dut, "com.oplus.camera:id/mode_close")
        dut.phoneui2.swipe_ext("left")
        time.sleep(2)
        ui2.click_with_description_exists(dut, "TEXT SCANNER", timeout=2)
        self.logger.info("checking in TEXT SCANNER mode")
        lib.check_volumeAction_zoom(dut)

        self.logger.info("Volume button as zoom working fine: PASS")

        # check RSA
        if asserttip.get_assert_state(dut) is True:
            raise ScriptFail("Red screen assertion found in dut")

    # def cleanup_iteration(self):
    #     """ Cleanup every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def cleanup_testcase(self):
        """ Cleanup every testcase executes

        :return:
        """
        # clear red screen
        if asserttip.get_assert_state(dut) is True:
            asserttip.clear_assert_red(dut)
        common.press_home_key(dut)
        time.sleep(2)
        common.clear_background_apps(dut, "all")


if __name__ == '__main__':
    tc = IN_Exploratory_001_003()
    tc.execute()
