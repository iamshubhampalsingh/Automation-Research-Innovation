#!/usr/bin/env python
# -*- coding: utf-8 -*-
# coding=utf-8

# ------------------------------------------------------------
# Copyright (C), 2008-2018, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2018-2019, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2019-2020, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2020-2021, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2021-2022, OPPO Mobile Comm Corp., Ltd.
# ------------------------------------------------------------
# Author: Akesh Srivastava(akesh.srivastava@oppo.com)
# ------------------------------------------------------------

import time
from olib_aw.base import TcBase
from olib_aw.base import common, asserttip, screen
from olib_aw.base import ScriptFail
from olib_scripts.libs.oplus_india import Library_camera as lib # pylint:disable=import-error
from olib_aw.utils import set_as_tc


@set_as_tc(
    project_name='India_Camera_localization_test',
    script_desc="""
    Check applied personalization color on camera UI.
    """,
    author='Akesh Srivastava (IN009394)',
    created_time='2022/08/08',
    modified_time='2022/08/08',
    modified_desc=""" """,
    pre_condition="""
    * initialize_testcase:
    * initialize_iteration
    """,
    test_steps="""
    *   1. Open camera > Click pictures in each mode from front and rear mode 
    *   2. Reboot the device 
    *   3. Open the camera again and perform step"

    """,
    post_condition="""
    * cleanup_iteration
    * cleanup_testcase    
    """,
    expection_result="""
    *   1.  Open camera properly, no RCA and stuck should observed  and all clicked pictures should save successfully 
    *   2.  ""SD card error. Camera is temporarily Unavailable"" error should not come after rebooting while opening the camera and should perform all operations normally"

    """,
    topology_dependencies=1,
    devices_tags=[["phoneDUT"]]
)
class IN_Exploratory_001_020(TcBase):
    """ This is the TC template class

    """

    def initialize_testcase(self):
        """ Initialize before every testcase executes

        :return:
        """
        global dut
        dut = self.topology.get_phone(label="phoneDUT")
        self.exception_all = []

    # def initialize_iteration(self):
    #     """ Initialize before every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def main(self):
        # open camera
        lib.launch_camera(dut)

        # check all modes
        lib.check_all_modes(dut)

        # reboot
        lib.reboot_device(dut)

        # open camera
        lib.launch_camera(dut)

        # check all modes after reboot
        lib.check_all_modes(dut)

        # check RSA
        if asserttip.get_assert_state(dut) is True:
            raise ScriptFail("Red screen assertion found in dut")

    # def cleanup_iteration(self):
    #     """ Cleanup every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def cleanup_testcase(self):
        """ Cleanup every testcase executes

        :return:
        """
        lib.cleanup_camera(dut)


if __name__ == '__main__':
    tc = IN_Exploratory_001_020()
    tc.execute()
