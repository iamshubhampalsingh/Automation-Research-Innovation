#!/usr/bin/env python
# -*- coding: utf-8 -*-
# coding=utf-8

# ------------------------------------------------------------
# Copyright (C), 2008-2018, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2018-2019, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2019-2020, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2020-2021, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2021-2022, OPPO Mobile Comm Corp., Ltd.
# ------------------------------------------------------------
# Author: Shubham Pal Singh(shubham.singh@oppo.com)
# ------------------------------------------------------------

import time
from olib_aw.base import TcBase
from olib_aw.base import common, asserttip
from olib_aw.teams.test_ui import ui_commont_ as ui2
from olib_aw.base import ScriptFail
from olib_scripts.libs.oplus_india import Library_camera as lib # pylint:disable=import-error
from olib_aw.utils import set_as_tc


@set_as_tc(
    project_name='India_Camera_localization_test',
    script_desc="""
    Check applied personalization color on camera UI.
    """,
    author='Shubham Pal Singh (IN009359)',
    created_time='2022/08/08',
    modified_time='2022/08/08',
    modified_desc=""" """,
    pre_condition="""
    * initialize_testcase:
    * initialize_iteration
    """,
    test_steps="""
    *   1. PHOTO mode (Rear camera) ---Settings ---Timer is set as 3s and 10s respectively---Take photo and check the preview.
    *   2. Switch to the front camera and repeat Step 1."   

    """,
    post_condition="""
    * cleanup_iteration
    * cleanup_testcase    
    """,
    expection_result="""
    *   1.2. Tap to take a photo, a "Di" prompt is accompanied and synchronized with the countdown number, which is consistent with the setting, after the countdown is end, a photo is taken, and the photo is generated immediately.

    """,
    topology_dependencies=1,
    devices_tags=[["phoneDUT"]]
)
class IN_CameraSanity_001_017(TcBase):
    """ This is the TC template class

    """

    def initialize_testcase(self):
        """ Initialize before every testcase executes

        :return:
        """
        global dut
        dut = self.topology.get_phone(label="phoneDUT")
        self.exception_all = []

    # def initialize_iteration(self):
    #     """ Initialize before every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def main(self):
        # open camera
        lib.launch_camera(dut)

        # check image capture in PHOTO mode rear
        self.logger.info("checking in PHOTO mode rear")
        # set timer to 3sec
        ui2.click_with_description_exists(dut, "Timernormal")
        time.sleep(2)
        ui2.click_with_xpath(dut, '//*[@resource-id="com.oplus.camera:id/camera_setting_layout_second_level"]/android.widget.ImageView[2]')
        time.sleep(2)
        if ui2.check_exists_description(dut, "Timer3"):
            self.logger.info("Timer set to 3 seconds")

        if lib.click_check(dut, wait=6):
            self.logger.info("Image captured and saved in rear photo mode: PASS")
        else:
            raise ScriptFail("Image capture and save failed")
        ui2.click_with_resource_id_exists(dut, "com.oplus.camera:id/thumbnail")
        time.sleep(2)
        common.press_back_key(dut)
        time.sleep(2)

        ui2.click_with_description_exists(dut, "Timer3")
        time.sleep(2)
        ui2.click_with_xpath(dut,
                             '//*[@resource-id="com.oplus.camera:id/camera_setting_layout_second_level"]/android.widget.ImageView[3]')
        time.sleep(2)
        if ui2.check_exists_description(dut, "Timer10"):
            self.logger.info("Timer set to 10 seconds")

        if lib.click_check(dut, wait=15):
            self.logger.info("Image captured and saved in rear photo mode: PASS")
        else:
            raise ScriptFail("Image capture and save failed")
        ui2.click_with_resource_id_exists(dut, "com.oplus.camera:id/thumbnail")
        time.sleep(2)
        common.press_back_key(dut)
        time.sleep(2)

        # check image capture in PHOTO mode front
        ui2.click_with_resource_id_exists(dut, "com.oplus.camera:id/switch_camera_button")
        self.logger.info("checking in PHOTO mode front")

        if ui2.check_exists_description(dut, "Timer10"):
            self.logger.info("Timer set to 10 seconds")

        if lib.click_check(dut, wait=15):
            self.logger.info("Image captured and saved in front photo mode: PASS")
        else:
            raise ScriptFail("Image capture and save failed")
        ui2.click_with_resource_id_exists(dut, "com.oplus.camera:id/thumbnail")
        time.sleep(2)
        common.press_back_key(dut)
        time.sleep(2)

        ui2.click_with_description_exists(dut, "Timer10")
        time.sleep(2)
        ui2.click_with_xpath(dut,
                             '//*[@resource-id="com.oplus.camera:id/camera_setting_layout_second_level"]/android.widget.ImageView[2]')
        time.sleep(2)
        if ui2.check_exists_description(dut, "Timer3"):
            self.logger.info("Timer set to 3 seconds")

        if lib.click_check(dut, wait=6):
            self.logger.info("Image captured and saved in front photo mode: PASS")
        else:
            raise ScriptFail("Image capture and save failed")
        ui2.click_with_resource_id_exists(dut, "com.oplus.camera:id/thumbnail")
        time.sleep(2)

        if asserttip.get_assert_state(dut) is True:
            raise ScriptFail("Red screen assertion found in dut")

    # def cleanup_iteration(self):
    #     """ Cleanup every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def cleanup_testcase(self):
        """ Cleanup every testcase executes

        :return:
        """
        # clear red screen
        if asserttip.get_assert_state(dut) is True:
            asserttip.clear_assert_red(dut)
        common.press_home_key(dut)
        time.sleep(2)
        common.clear_background_apps(dut, "all")


if __name__ == '__main__':
    tc = IN_CameraSanity_001_017()
    tc.execute()
