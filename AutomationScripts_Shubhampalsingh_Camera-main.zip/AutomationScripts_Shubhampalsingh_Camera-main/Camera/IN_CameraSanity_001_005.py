#!/usr/bin/env python
# -*- coding: utf-8 -*-
# coding=utf-8

# ------------------------------------------------------------
# Copyright (C), 2008-2018, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2018-2019, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2019-2020, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2020-2021, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2021-2022, OPPO Mobile Comm Corp., Ltd.
# ------------------------------------------------------------
# Author: Shubham Pal Singh(shubham.singh@oppo.com)
# ------------------------------------------------------------

import time
from olib_aw.base import TcBase
from olib_aw.base import common, asserttip
from olib_aw.teams.test_ui import ui_commont_ as ui2
from olib_aw.base import ScriptFail, PreconditionsException
from olib_scripts.libs.oplus_india import Library_camera as lib # pylint:disable=import-error
from olib_aw.utils import set_as_tc


@set_as_tc(
    project_name='India_Camera_localization_test',
    script_desc="""
    Check applied personalization color on camera UI.
    """,
    author='Shubham Pal Singh (IN009359)',
    created_time='2022/08/08',
    modified_time='2022/08/08',
    modified_desc=""" """,
    pre_condition="""
    * initialize_testcase:
    * initialize_iteration
    """,
    test_steps="""
    *   1.Tap the camera icon on the home screen, check whether the camera can be entered .
    *   2.Check preview screen, each control UI and thumbnail display.
    *   3.Tap to take photo, check the thumbnail display.
    *   4.Switch to VIDEO mode, tap the record button to record 5~10s, check thumbnail display.

    """,
    post_condition="""
    * cleanup_iteration
    * cleanup_testcase    
    """,
    expection_result="""
    *   1.Enter the camera UI smoothly(the entry speed is not slower than the Reference-device).
    *   2.The preview screen and UI display are normal, and the thumbnail is displayed as the last photo taken.
    *   3.The DUT can take photos normally, and the thumbnail is displayed as the photo just taken.
    *   4.The DUT can record video normally, and the thumbnail is displayed as the first frame screen of the video.

    """,
    topology_dependencies=1,
    devices_tags=[["phoneDUT"]]
)
class IN_CameraSanity_001_005(TcBase):
    """ This is the TC template class

    """

    def initialize_testcase(self):
        """ Initialize before every testcase executes

        :return:
        """
        global dut
        dut = self.topology.get_phone(label="phoneDUT")
        self.exception_all = []

    # def initialize_iteration(self):
    #     """ Initialize before every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def main(self):
        # open camera
        common.press_home_key(dut)
        time.sleep(2)
        common.app_initialization(dut, "com.oplus.camera")

        if ui2.check_exists_description(dut, "Camera"):
            ui2.click_with_description_exists(dut, "Camera")
            time.sleep(2)
        else:
            raise PreconditionsException("Camera app not available on Home screen")

        ui2.click_with_resource_id_exists(dut, "com.android.permissioncontroller:id/permission_allow_button")
        time.sleep(2)
        ui2.click_with_resource_id_exists(dut, "com.oplus.camera:id/btn_confirm")
        time.sleep(2)
        ui2.click_with_resource_id_exists(dut,
                                          "com.android.permissioncontroller:id/permission_allow_foreground_only_button")
        time.sleep(2)

        if common.is_activity_exist(dut, "com.oplus.camera", "com.oplus.camera.Camera"):
            self.logger.info("Camera app launched successfully from Home screen: PASS")
        else:
            raise ScriptFail("Camera app failed to launch successfully from Home screen")

        # click photo
        if lib.click_check(dut):
            self.logger.info("Photo clicked and saved successfully: PASS")
        else:
            raise ScriptFail("Photo failed to be clicked and saved.")

        # click video
        dut.phoneui2.swipe_ext("right")
        time.sleep(2)
        if lib.click_check_video(dut):
            self.logger.info("Video recorded and saved successfully: PASS")
        else:
            raise ScriptFail("Video failed to be recorded and saved")

        # check RSA
        if asserttip.get_assert_state(dut) is True:
            raise ScriptFail("Red screen assertion found in dut")

    # def cleanup_iteration(self):
    #     """ Cleanup every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def cleanup_testcase(self):
        """ Cleanup every testcase executes

        :return:
        """
        # clear red screen
        if asserttip.get_assert_state(dut) is True:
            asserttip.clear_assert_red(dut)
        common.press_home_key(dut)
        time.sleep(2)
        common.clear_background_apps(dut, "all")


if __name__ == '__main__':
    tc = IN_CameraSanity_001_005()
    tc.execute()
