#!/usr/bin/env python
# -*- coding: utf-8 -*-
# coding=utf-8

# ------------------------------------------------------------
# Copyright (C), 2008-2018, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2018-2019, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2019-2020, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2020-2021, OPPO Mobile Comm Corp., Ltd.
# Copyright (C), 2021-2022, OPPO Mobile Comm Corp., Ltd.
# ------------------------------------------------------------
# Author: Akesh Srivastava(akesh.srivastava@oppo.com)
# ------------------------------------------------------------

import time
from olib_aw.base import TcBase
from olib_aw.base import common, asserttip
from olib_aw.teams.test_ui import ui_commont_ as ui2
from olib_aw.base import ScriptFail
from olib_scripts.libs.oplus_india import Library_camera as lib # pylint:disable=import-error
from olib_aw.utils import set_as_tc


@set_as_tc(
    project_name='India_Camera_localization_test',
    script_desc="""
    Check applied personalization color on camera UI.
    """,
    author='Akesh Srivastava (IN009394)',
    created_time='2022/08/08',
    modified_time='2022/08/08',
    modified_desc=""" """,
    pre_condition="""
    * initialize_testcase:
    * initialize_iteration
    """,
    test_steps="""
    *   1. Open the camera 
    *   2. Open every mode in camera"

    """,
    post_condition="""
    * cleanup_iteration
    * cleanup_testcase    
    """,
    expection_result="""
    *   1. Camera should open properly
    *   2. Status bar should be visible in every mode of camera eg. Photo , video, portrait, expert, sticker, night, movie, time lapse, slo mo, text scanner etc.

    """,
    topology_dependencies=1,
    devices_tags=[["phoneDUT"]]
)
class IN_Exploratory_001_010(TcBase):
    """ This is the TC template class

    """

    def initialize_testcase(self):
        """ Initialize before every testcase executes

        :return:
        """
        global dut
        dut = self.topology.get_phone(label="phoneDUT")
        self.exception_all = []

    # def initialize_iteration(self):
    #     """ Initialize before every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def main(self):
        # open camera
        lib.launch_camera(dut)

        # check status bar in PHOTO mode
        self.logger.info("checking in PHOTO mode")
        lib.check_status_bar(dut)
        time.sleep(5)

        # check status bar in NIGHT mode
        dut.phoneui2.swipe_ext("right")
        dut.phoneui2.swipe_ext("right")
        time.sleep(2)
        self.logger.info("checking in NIGHT mode")
        lib.check_status_bar(dut)
        time.sleep(5)

        # check status bar in VIDEO mode
        dut.phoneui2.swipe_ext("left")
        time.sleep(2)
        self.logger.info("checking in VIDEO mode")
        lib.check_status_bar(dut)
        time.sleep(5)

        # check status bar in PORTRAIT mode
        dut.phoneui2.swipe_ext("left")
        dut.phoneui2.swipe_ext("left")
        time.sleep(2)
        self.logger.info("checking in PORTRAIT mode")
        lib.check_status_bar(dut)
        time.sleep(5)

        # check status bar in PRO mode
        dut.phoneui2.swipe_ext("left")
        time.sleep(2)
        ui2.click_with_description_exists(dut, "PRO", timeout=3)
        self.logger.info("checking in PRO mode")
        lib.check_status_bar(dut)
        time.sleep(5)

        # check status bar in EXTRA_HD mode
        ui2.click_with_resource_id_exists(dut, "com.oplus.camera:id/mode_close")
        dut.phoneui2.swipe_ext("left")
        time.sleep(2)
        ui2.click_with_description_exists(dut, "EXTRA HD", timeout=3)
        time.sleep(3)
        self.logger.info("checking in EXTRA HD mode")
        lib.check_status_bar(dut)
        time.sleep(5)

        # check status bar in PANO mode
        ui2.click_with_resource_id_exists(dut, "com.oplus.camera:id/mode_close")
        dut.phoneui2.swipe_ext("left")
        time.sleep(2)
        ui2.click_with_description_exists(dut, "PANO", timeout=3)
        time.sleep(3)
        self.logger.info("checking in PANO mode")
        lib.check_status_bar(dut)
        time.sleep(5)

        # check status bar in MACRO mode
        ui2.click_with_resource_id_exists(dut, "com.oplus.camera:id/mode_close")
        dut.phoneui2.swipe_ext("left")
        time.sleep(2)
        ui2.click_with_description_exists(dut, "MACRO", timeout=3)
        time.sleep(3)
        self.logger.info("checking in MACRO mode")
        lib.check_status_bar(dut)
        time.sleep(5)

        # check status bar in SLO-MO mode
        ui2.click_with_resource_id_exists(dut, "com.oplus.camera:id/mode_close")
        dut.phoneui2.swipe_ext("left")
        time.sleep(2)
        ui2.click_with_description_exists(dut, "SLO-MO", timeout=3)
        time.sleep(3)
        self.logger.info("checking in SLO-MO mode")
        lib.check_status_bar(dut)
        time.sleep(5)

        # check status bar in TIME-LAPSE mode
        ui2.click_with_resource_id_exists(dut, "com.oplus.camera:id/mode_close")
        dut.phoneui2.swipe_ext("left")
        time.sleep(2)
        ui2.click_with_description_exists(dut, "TIME-LAPSE", timeout=3)
        time.sleep(3)
        self.logger.info("checking in TIME-LAPSE mode")
        lib.check_status_bar(dut)
        time.sleep(5)

        # check status bar in DUAL-VIEW VIDEO mode
        ui2.click_with_resource_id_exists(dut, "com.oplus.camera:id/mode_close")
        dut.phoneui2.swipe_ext("left")
        time.sleep(2)
        ui2.click_with_description_exists(dut, "DUAL-VIEW VIDEO", timeout=3)
        time.sleep(3)
        self.logger.info("checking in DUAL-VIEW VIDEO mode")
        lib.check_status_bar(dut)
        time.sleep(5)

        # check status bar in STICKER mode
        ui2.click_with_resource_id_exists(dut, "com.oplus.camera:id/mode_close")
        dut.phoneui2.swipe_ext("left")
        time.sleep(2)
        ui2.click_with_description_exists(dut, "STICKER", timeout=3)
        time.sleep(3)
        self.logger.info("checking in STICKER mode")
        lib.check_status_bar(dut)
        time.sleep(5)

        # check status bar in TEXT SCANNER mode
        ui2.click_with_resource_id_exists(dut, "com.oplus.camera:id/mode_close")
        dut.phoneui2.swipe_ext("left")
        time.sleep(2)
        ui2.click_with_description_exists(dut, "TEXT SCANNER", timeout=3)
        time.sleep(3)
        self.logger.info("checking in TEXT SCANNER mode")
        lib.check_status_bar(dut)
        time.sleep(5)

        # check RSA
        if asserttip.get_assert_state(dut) is True:
            raise ScriptFail("Red screen assertion found in dut")

    # def cleanup_iteration(self):
    #     """ Cleanup every iteration executes
    #
    #     :return:
    #     """
    #     pass

    def cleanup_testcase(self):
        """ Cleanup every testcase executes

        :return:
        """
        # clear red screen
        if asserttip.get_assert_state(dut) is True:
            asserttip.clear_assert_red(dut)
        common.press_home_key(dut)
        time.sleep(2)
        common.clear_background_apps(dut, "all")


if __name__ == '__main__':
    tc = IN_Exploratory_001_010()
    tc.execute()
