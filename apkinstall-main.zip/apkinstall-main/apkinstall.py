import os
import sys
import unittest
import time
import subprocess

from androidutils.device import Device, BootMode
from androidutils.ssts import Utils
from ppadb.client import Client as adbclient

## Logs -start
from androidutils.pylogging import PyLogger
logger = PyLogger.getlogger(__name__)
logc = logger.critical
loge = logger.error
logw = logger.warning
logd = logger.debug
logi = logger.info
## Logs -end


class ApkInstall(unittest.TestCase):
    """
    A class to handle ApkInstall test case
    """
    ssts_utils = None

    def __init__(self, *args, **kwargs):
      super(ApkInstall, self).__init__(*args, **kwargs)
      self.classname = self.__class__.__name__

    @classmethod
    def setUpClass(cls):
      logw("setup")
      cls.dev = Device()
      cls.ssts_utils = Utils(adbclient(host='127.0.0.1', port=5037).devices()[0])

    @classmethod
    def tearDownClass(cls):
      logw("teardown")
      cls.dev.adbclient.remote_disconnect()

    def msg(self, tag, msg):
       return ("[{}#{}]: {}".format(self.dev.name, tag, msg))

    def start(self, test_case_name):
      logw(self.msg(test_case_name, '---------------------------------'))
      logw(self.msg(test_case_name, "Start test: " + test_case_name))
      logw(self.msg(test_case_name, '---------------------------------'))

    def test_System_APKINSTALL_001_Uninstall_app(self):
      tag = self.classname + "." + self.test_System_APKINSTALL_001_Uninstall_app.__name__
      self.dev.set_tag(tag)
      self.start(tag)
      d = self.dev.uidevice

      ssts_root_path = os.getenv("SSTS_ROOT_PATH")
      ssts_testcases_path = ssts_root_path + "/testcases"
      file = ssts_testcases_path + "/apk/FillRam.apk"

      if(os.path.exists(file) == False):
          self.fail("APK not present")

      # Install a apk
      subprocess.check_output("adb install %s" % (file), shell=True)
      outputInstall = subprocess.check_output("adb shell pm list packages me.empirical.android.application.fillmemory", shell=True).decode('ascii').strip()

      if(outputInstall != "package:me.empirical.android.application.fillmemory"):
          self.fail("Install failed")

      # Uninstall apk
      outputUninstall = subprocess.check_output("adb uninstall me.empirical.android.application.fillmemory", shell=True).decode('ascii').strip()

      if(outputUninstall != "Success"):
          self.fail("Uninstall failed")

      pass

    def test_System_APKINSTALL_002_Install_Uninstall_app_factoryreset(self):
      tag = self.classname + "." + self.test_System_APKINSTALL_002_Install_Uninstall_app_factoryreset.__name__
      self.dev.set_tag(tag)
      self.start(tag)
      d = self.dev.uidevice

      ssts_root_path = os.getenv("SSTS_ROOT_PATH")
      ssts_testcases_path = ssts_root_path + "/testcases"
      file = ssts_testcases_path + "/apk/FillRam.apk"

      if(os.path.exists(file) == False):
          self.fail("APK not present")

      # Install a apk
      subprocess.check_output("adb install %s" % (file), shell=True)
      outputInstall = subprocess.check_output("adb shell pm list packages me.empirical.android.application.fillmemory", shell=True).decode('ascii').strip()
      if(outputInstall != "package:me.empirical.android.application.fillmemory"):
          self.fail("Install failed")

      # Uninstall apk
      outputUninstall = subprocess.check_output("adb uninstall me.empirical.android.application.fillmemory", shell=True).decode('ascii').strip()
      if(outputUninstall != "Success"):
          self.fail("Uninstall failed")

      if(self.dev.is_screen_locked()):
          self.dev.unlock_lockscreen()

      # factory reset
      logi(self.msg(tag, 'Initiate factory reset'))
      self.dev.fdr_from_settings(erase_all=False, passcode=False)
      before_reboot_name = self.dev.name
      if self.dev.wait_for_device(timeout=300) is not True:
        loge(self.msg(tag,"Unable detect adb device after factory data reset"))
        self.fail("Device didn't detected after reboot " + before_reboot_name)

      ## wait till home screen starts
      status = self.dev.wait_and_get_homescreen_status()
      if status['ret'] != True:
        loge(self.msg(tag,"Failed to get home screen status after factory data reset"))

      # Test suite utils
      self.ssts_utils = Utils(self.dev.adbdevice)
      self.ssts_utils.skip_setupwizard()
      self.ssts_utils.grant_atx_runtime_permissions()

      # Check reboot reason
      logi(self.msg(tag,"CheckPoint: Boot reason after factory data reset."))
      actual_reboot_reason = self.dev.get_property("sys.boot.reason")
      expected_reboot_reason = 'reboot,factory_reset'
      if actual_reboot_reason != expected_reboot_reason:
        loge(self.msg(tag, "actual_reboot_reason=" + actual_reboot_reason \
          + " expected_reboot_reason=" + expected_reboot_reason))
        self.fail("Factory data reset failed")

      logi(self.msg(tag, tag + '= PASS'))


    def test_System_APKINSTALL_003_Amazon_apps(self):
      tag = self.classname + "." + self.test_System_APKINSTALL_003_Amazon_apps.__name__
      self.dev.set_tag(tag)
      self.start(tag)
      d = self.dev.uidevice

      #check amazon apps
      outputAmazonShopping = subprocess.check_output("adb shell pm list packages in.amazon.mShop.android.shopping", shell=True).decode('ascii').strip()
      outputAmazonKindle = subprocess.check_output("adb shell pm list packages com.amazon.kindle", shell=True).decode('ascii').strip()
      outputAmazonPrimeVideo = subprocess.check_output("adb shell pm list packages com.amazon.avod.thirdpartyclient", shell=True).decode('ascii').strip()
      outputAmazonMDIP = subprocess.check_output("adb shell pm list packages com.amazon.appmanager", shell=True).decode('ascii').strip()

      if(outputAmazonShopping != "package:in.amazon.mShop.android.shopping"):
          self.fail("Amazon Shopping not present")

      if(outputAmazonPrimeVideo != "package:com.amazon.avod.thirdpartyclient"):
          self.fail("Prime Video not present")

      if(outputAmazonMDIP != "package:com.amazon.appmanager"):
          self.fail("MDIP not present")

      if(outputAmazonKindle != "package:com.amazon.kindle"):
          if(subprocess.check_output("adb shell getprop ro.boot.project_name", shell=True).decode('ascii').strip() != "20801"):
              self.fail("MDIP not present")

      pass

    def test_System_APKINSTALL_004_sdcard_install(self):
      tag = self.classname + "." + self.test_System_APKINSTALL_004_sdcard_install.__name__
      self.dev.set_tag(tag)
      self.start(tag)
      d = self.dev.uidevice

      ssts_utils = Utils(adbclient(host='127.0.0.1', port=5037).devices()[0])

      ssts_root_path = os.getenv("SSTS_ROOT_PATH")
      ssts_testcases_path = ssts_root_path + "/testcases"
      file = ssts_testcases_path + "/apk/FillRam.apk"

      if(os.path.exists(file) == False):
          self.fail("APK not present")

      subprocess.check_output("adb push %s /sdcard/"% (file), shell=True)
      subprocess.check_output("adb shell am start \"com.oneplus.filemanager/.HomePageActivity\" -a android.intent.action.MAIN -c android.intent.category.LAUNCHER", shell=True)

      d.wait_activity("com.oneplus.filemanager.HomePageActivity", timeout=5)
      time.sleep(2)

      output = self.dev.adbdevice.shell("dumpsys window | grep -i mFocus").strip()
      logd(self.msg(tag, 'output = %s'%output))

      if d(text='Storage').exists(timeout=5):
          d(text='Storage').click()
      else:
          # debug code fr capturing screenshot
          self.dev.adbdevice.shell("screencap /sdcard/apkinstall.png").strip()
          screenshot = ssts_utils.current_log_path + "/"
          pull = "adb pull /sdcard/apkinstall.png "+screenshot
          subprocess.check_output(pull, shell=True).decode('ascii').strip()

      d(text='Internal storage').click()
      d(scrollable=True).fling.toEnd()
      d(text='FillRam.apk').click()
      time.sleep(1)
      if(d(text='SETTINGS').exists):
          d(text='SETTINGS').click()
          d(text='Allow from this source').click()
          subprocess.check_output("adb shell input keyevent 4", shell=True)
      d(text='INSTALL').click()
      time.sleep(20)

      output = subprocess.check_output("adb shell pm list packages me.empirical.android.application.fillmemory", shell=True).decode('ascii').strip()
      if(output != "package:me.empirical.android.application.fillmemory"):
          self.fail("Installation from sdcard failed")
      pass

    def test_System_APKINSTALL_005_Install_app(self):
      tag = self.classname + "." + self.test_System_APKINSTALL_005_Install_app.__name__
      self.dev.set_tag(tag)
      self.start(tag)
      d = self.dev.uidevice

      ssts_root_path = os.getenv("SSTS_ROOT_PATH")
      ssts_testcases_path = ssts_root_path + "/testcases"
      file = ssts_testcases_path + "/apk/FillRam.apk"

      if(os.path.exists(file) == False):
          self.fail("APK not present")

      # Uninstall apk
      try:
        outputUninstall = subprocess.check_output("adb uninstall me.empirical.android.application.fillmemory", shell=True).decode('ascii').strip()
      except subprocess.CalledProcessError as e:
        logw(self.msg(tag, 'uninstall failed'))

      # Install a apk
      subprocess.check_output("adb install %s" % (file), shell=True)
      outputInstall = subprocess.check_output("adb shell pm list packages me.empirical.android.application.fillmemory", shell=True).decode('ascii').strip()

      if(outputInstall != "package:me.empirical.android.application.fillmemory"):
          self.fail("Install failed")
      pass

    def test_System_APKINSTALL_006_Install_from_oneplus_store(self):
      tag = self.classname + "." + self.test_System_APKINSTALL_006_Install_from_oneplus_store.__name__
      self.dev.set_tag(tag)
      self.start(tag)

      # check os compatibility
      build_version_type = self.dev.get_property("persist.sys.oem.region")
      if build_version_type == "OverSeas":
        self.skipTest("Not applicable for Overseas")

      self.fail("Not automated yet. Please check manually")

